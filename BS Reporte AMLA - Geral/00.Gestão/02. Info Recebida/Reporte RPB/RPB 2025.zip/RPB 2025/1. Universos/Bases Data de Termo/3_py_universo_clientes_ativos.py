# Databricks notebook source
# DBTITLE 1,Variáveis
#importar bibliotecas spark
from pyspark.sql.functions import col

#declaração de variáveis
data_date_part = "'2025-12-31'"

print(data_date_part)

# COMMAND ----------

# DBTITLE 1,Universo Clientes Distintos
## Universo de Clientes
tbl_clientes_alvo = spark.sql(f"""
                          
select distinct party_id, partenon_id, left(partenon_id, 1) as Tipo_Cliente
from workbench_fcc.rpb25_universo_contratos_relacoes
union all
select distinct party_id, cpers as partenon_id, 'BEF' as Tipo_Cliente
from workbench_fcc.rpb25_universo_befs

""")

tbl_clientes_alvo.createOrReplaceTempView("clientes_alvo")

tbl_clientes_alvo.display()
#tbl_clientes_alvo.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC select Tipo_Cliente, count(*) as Total
# MAGIC from clientes_alvo
# MAGIC group by Tipo_Cliente

# COMMAND ----------

# DBTITLE 1,Identificação País de Residência
tbl_res_fisicos = spark.sql(f"""
                          
select distinct a.party_id, a.order_number, a.start_date, a.address_type_code, a.country_code, b.CPAIS_P, a.full_address
from common_parties_individuals.individual_address a
left join
(
    select *
    from curated_internal_mainframe_estruturais.tat03_paises
    where data_date_part = {data_date_part}    
) b 
on a.country_code = b.CPAIS_S
where a.data_date_part = {data_date_part}
and a.address_type_code = '01'

""")

tbl_res_juridicos = spark.sql(f"""
       
select distinct a.party_id, a.order_number, a.start_date, a.address_type_code, a.country_code, b.CPAIS_P, a.full_address
from common_parties_entities.entity_address a
left join
(
    select *
    from curated_internal_mainframe_estruturais.tat03_paises
    where data_date_part = {data_date_part}    
) b 
on a.country_code = b.CPAIS_S
where a.data_date_part = {data_date_part}
and a.address_type_code = '01'

""")

tbl_res_fisicos.createOrReplaceTempView("res_fisicos")
tbl_res_juridicos.createOrReplaceTempView("res_juridicos")
#tbl_res_fisicos.filter(col("party_id") == '7402308104').display()
#tbl_res_juridicos.display()
#tbl_res_fisicos.count()
#tbl_res_juridicos.count()

print('Existem',tbl_res_fisicos.count(), 'clientes singulares e ', tbl_res_juridicos.count(), 'clientes juridicos.')

# COMMAND ----------

# DBTITLE 1,Identificação do Pais de Naturalidade
tbl_birth_fisicos = spark.sql(f"""
                          
select distinct a.party_id, a.birth_country_code, b.CPAIS_P
from common_parties_individuals.individual a
left join
(
    select *
    from curated_internal_mainframe_estruturais.tat03_paises
    where data_date_part = {data_date_part}    
) b 
on a.birth_country_code = b.CPAIS_S
where a.data_date_part = {data_date_part}

""")

tbl_origin_juridicos = spark.sql(f"""
       
select distinct a.party_id, a.origin_country_code, b.CPAIS_P
from common_parties_entities.entity a
left join
(
    select *
    from curated_internal_mainframe_estruturais.tat03_paises
    where data_date_part = {data_date_part}    
) b 
on a.origin_country_code = b.CPAIS_S
where a.data_date_part = {data_date_part}

""")

tbl_birth_fisicos.createOrReplaceTempView("birth_fisicos")
tbl_origin_juridicos.createOrReplaceTempView("origin_juridicos")
#tbl_birth_fisicos.filter(col("party_id") == '7402308104').display()
#tbl_origin_juridicos.display()

# COMMAND ----------

# DBTITLE 1,Identificação País de Nacionalidade
tbl_nac_fisicos = spark.sql(f"""
                          
select distinct 
    a.party_id,
    concat_ws(',', collect_set(a.order_number)) AS order_number,
    concat_ws(',', collect_set(a.country_code)) AS country_code,
    concat_ws(',', collect_set(b.CPAIS_P)) AS CPAIS_P
from common_parties_individuals.individual_citizenship a
left join
(
    select *
    from curated_internal_mainframe_estruturais.tat03_paises
    where data_date_part = {data_date_part}    
) b 
on a.country_code = b.CPAIS_S
where a.data_date_part = {data_date_part}
group by a.party_id
""")

tbl_nac_fisicos.createOrReplaceTempView("nac_fisicos")
#tbl_nac_fisicos.display()
tbl_nac_fisicos.count()

# COMMAND ----------

# DBTITLE 1,Identificação da Data de Criação do Cliente
tbl_data_criac = spark.sql(f"""

select party_id, min(opening_date) as data_inic_relac_conta
from workbench_fcc.rpb25_universo_contratos_relacoes group by party_id

""")

tbl_data_criac.createOrReplaceTempView("data_criacao")
tbl_data_criac.count()

# COMMAND ----------

# DBTITLE 1,Identificação do Risco AML
tbl_risco = spark.sql(f"""                      
select distinct replace(customer_id, 'TOT','') as customer_id, assigned_risk_id, 
    case when assigned_risk_id in ('1000','1003','1005') then 'A'
    when assigned_risk_id in ('1001','1004','1007') then 'M'
    when assigned_risk_id in ('1002','1006') then 'B' else 'B' end as risco_dsc,
    SCORE_TIMESTAMP, data_date_part
from curated_internal_norkom.cdd_customer_score
where data_date_part = {data_date_part}
""")

tbl_risco.createOrReplaceTempView("risco")
#tbl_risco.display()
tbl_risco.count()

# COMMAND ----------

# DBTITLE 1,Identificação da Entidade Patronal
tbl_entid_patron = spark.sql(f"""
                          
select distinct a.party_id, a.employer_name
from common_parties_individuals.individual a
where a.data_date_part = {data_date_part}

""")

tbl_entid_patron.createOrReplaceTempView("entidade_patronal")
#tbl_entid_patron.display()
tbl_entid_patron.count()

# COMMAND ----------

# DBTITLE 1,Identificação de CAEs
tbl_cae = spark.sql(f"""
                          
select distinct a.party_id, a.industry_classific_system_code, a.order_number, a.econ_activity_category_code, b.TAYD91C0_GELEMTAB as econ_activity_category_desc
from
( 
    select * from common_parties_entities.entity_economic_activity where data_date_part = {data_date_part}
    union all
    select * from common_parties_individuals.individual_economic_activity where data_date_part = {data_date_part}
) a
left join
(
  select * 
  from curated_internal_mainframe_estruturais.tat91_tabelas 
  where data_date_part = {data_date_part}
  and TAYD91C0_CTABELA = '154'
) b
on  a.econ_activity_category_code = b.TAYD91C0_CELEMTAB

""")

tbl_cae.createOrReplaceTempView("cae")
#tbl_cae.display()
tbl_cae.count()

# COMMAND ----------

# DBTITLE 1,Identificação de Tipo de Sociedade
## Tipo de Sociedade para identificar Heranças Jacentes e Massas Insolventes

tbl_tipo_soc = spark.sql(f"""
                     
select distinct a.ZCLIENTE, a.NOMER, a.CTIPSOC, b.TAYD91C0_GELEMTAB as DSC_TIPSOC
from curated_internal_mainframe_clientes.clt45_fcli a
left join
(
    select * 
    from curated_internal_mainframe_estruturais.tat91_tabelas 
    where TAYD91C0_CTABELA = 'J90' 
    and data_date_part = {data_date_part}
) b
on a.CTIPSOC = b.TAYD91C0_CELEMTAB
where a.data_date_part = {data_date_part}
and a.CTIPSOC in (18, 19)

""")

tbl_tipo_soc.createOrReplaceTempView("socied_heranc_massa_insolvencia")
#tbl_tipo_soc.display()
tbl_tipo_soc.count()

# COMMAND ----------

# DBTITLE 1,Identificação de Natureza Jurídica
tbl_naturez_jurid = spark.sql(f"""
                          
select distinct a.party_id, a.legal_nature_code, b.TAYD91C0_GELEM30 as dsc_legal_nature_code
from common_parties_entities.entity a
left join
(
    select * 
    from curated_internal_mainframe_estruturais.tat91_tabelas 
    where TAYD91C0_CTABELA = '159' 
    and data_date_part = {data_date_part}
) b
on b.TAYD91C0_CELEMTAB = a.legal_nature_code
where a.data_date_part = {data_date_part}

""")

tbl_naturez_jurid.createOrReplaceTempView("natureza_juridica")
#tbl_naturez_jurid.display()
tbl_naturez_jurid.count()

# COMMAND ----------

# DBTITLE 1,Identificação de PEPs
aux_ind_pep = spark.sql(f"""

select  distinct zcliente, iclipep, case when CCARPEP = '17' then 'PROXIMO FAMILIA' when CCARPEP = '18' then 'PESSOA RECONH ESTRIT ASSOC' else 'PEP' end as Tipo_PEP
from  	curated_internal_mainframe_clientes.clt45_fcli
where	data_date_part = {data_date_part}
and 	iclipep <> 'N' and iclipep <> ''

""")

aux_ind_pep.createOrReplaceTempView("peps")
#aux_ind_pep.display()
aux_ind_pep.count()

# COMMAND ----------

# DBTITLE 1,Identificação de TOCPPs
aux_ind_tocpp = spark.sql(f"""

select  concat(substr(E2089_TIPO_PERS,1,1), CAST(CAST(substr(E2089_COD_PERS,2,9) AS BIGINT) AS string)) as cpersona,
        'TOCPP' as categoria 
from    curated_internal_mainframe_clientes.pers_normat_t02
where   1=1
and     E2089_TIPCARPU in ('080','084')
and     data_date_part = {data_date_part}

""")

aux_ind_tocpp.createOrReplaceTempView("tocpp")
#aux_ind_tocpp.display()
aux_ind_tocpp.count()

# COMMAND ----------

# DBTITLE 1,Identificação de Património Líquido
tbl_patrimonio = spark.sql(f"""
select  zcliente, cast(sum(Saldo_PASSIVO) - sum(Saldo_ACTIVO) as double) as Patrimonio 
from 
(
    select  
            concat(ct.ckbalcao,ct.cknumcta) AS num_conta_15d, zcliente,
            sum(case when nivel_2 = 'P' then ct.c001 end) as Saldo_PASSIVO,
            sum(case when nivel_2 = 'A' then ct.c001 end) as Saldo_ACTIVO,
            sum(ct.c001) as VN
    from    curated_internal_datalake_ctools.ct209_rent_kpm as ct 
    left join 
    (
            select  distinct nivel_1, nivel_2, nivel_3, nivel_12 
            from    curated_internal_datalake_ctools.ct011_dim_hier 
            where   ref_date = {data_date_part}
    ) AS hier 
    on      hier.nivel_12=ct.ckmetamis 
    where   ct.ref_Date = {data_date_part}
    group by 
            concat(ct.ckbalcao, ct.cknumcta), zcliente
) a group by zcliente
""")

tbl_patrimonio.createOrReplaceTempView("patrimonio")
#tbl_patrimonio.display()
#tbl_patrimonio.filter(col("zcliente")=='7402357521').display()
tbl_patrimonio.count()

# COMMAND ----------

# DBTITLE 1,Identificação de Organizações sem Fins Lucrativos
tbl_org_s_fins_lucra = spark.sql(f"""
                          
select distinct a.party_id, a.industry_classific_system_code, a.order_number, a.econ_activity_category_code, b.TAYD91C0_GELEMTAB as econ_activity_category_desc
from
( 
    select * from common_parties_entities.entity_economic_activity where data_date_part = {data_date_part}
    union all
    select * from common_parties_individuals.individual_economic_activity where data_date_part = {data_date_part}
) a
left join
(
  select * 
  from curated_internal_mainframe_estruturais.tat91_tabelas 
  where data_date_part = {data_date_part}
  and TAYD91C0_CTABELA = '154'
) b
on  a.econ_activity_category_code = b.TAYD91C0_CELEMTAB
where a.econ_activity_category_code in ('94991','94992','94993','94994','94995','94200','94110','94910','84210')

""")

tbl_org_s_fins_lucra.createOrReplaceTempView("organiz_s_fins_lucrativos")
#tbl_org_s_fins_lucra.display()
tbl_org_s_fins_lucra.count()

# COMMAND ----------

# DBTITLE 1,Identificação de Atividades de Risco Elevado
tbl_ativid_risco_elevado = spark.sql(f"""
                          
select distinct a.party_id, a.industry_classific_system_code, a.order_number, a.econ_activity_category_code, b.TAYD91C0_GELEMTAB as econ_activity_category_desc
from
( 
    select * from common_parties_entities.entity_economic_activity where data_date_part = {data_date_part}
    union all
    select * from common_parties_individuals.individual_economic_activity where data_date_part = {data_date_part}
) a
left join
(
  select * 
  from curated_internal_mainframe_estruturais.tat91_tabelas 
  where data_date_part = {data_date_part}
  and TAYD91C0_CTABELA = '154'
) b
on  a.econ_activity_category_code = b.TAYD91C0_CELEMTAB
where a.econ_activity_category_code in ('24410','24450','32122','32123','46190','46480','46820','47770','47783','47790','47910','47920','49200','49410','50200','50400','51210','64310','64320','66120','66300','68110','68120','68200','68310','68321','68323','68324','80011','82990','84210','92001','92002','93120','93192','94110','94200','94910','94991','94992','94993','94994','94995')

""")

tbl_ativid_risco_elevado.createOrReplaceTempView("atividades_risco_elevado")
#tbl_ativid_risco_elevado.display()
tbl_ativid_risco_elevado.count()

# COMMAND ----------

# DBTITLE 1,Identificação de ARIs
tbl_aris = spark.sql(f"""
                     
select ZCLIENTE, DTINICIO
from (
    select *
    from curated_internal_mainframe_clientes.clt44_infadic
    where 1=1
    and data_date_part = {data_date_part}
    and INDICADOR = 'IAR' and DESCRICAO = 'S'
    and DTFIM > {data_date_part}
) a

""")

tbl_aris.createOrReplaceTempView("aris")
tbl_aris.count()

# COMMAND ----------

# DBTITLE 1,Identificação de Estruturas Complexas
tbl_complexas = spark.sql(f"""
                     
select distinct *
from (
    select *
    from workbench_fcc.rpb25_estruturas_complexas
    where 1=1
    and CTIPPRO in ('2', '1')
) a

""")

tbl_complexas.createOrReplaceTempView("estruturas_complexas")
tbl_complexas.count()
#tbl_complexas.display()

# COMMAND ----------

# DBTITLE 1,Identificação de Depósitos em Numerário
# MAGIC %sql
# MAGIC
# MAGIC select 
# MAGIC   party_id, 
# MAGIC   count(distinct transaction_id) as Num_Transacoes, 
# MAGIC   sum(montante_eur) as Total_Transacoes, 
# MAGIC   sum(case when montante_eur > 100000 then 1 else 0 end) as Num_Transacoes_Unitarias_Intensivas
# MAGIC from
# MAGIC (
# MAGIC   select 
# MAGIC     distinct
# MAGIC     a.transaction_id, a.associated_contract_id, a.party_id, a.transaction_request_date, trim(c.element_description) as desc_moeda, 
# MAGIC     case when a.currency_code <> '978' then round(amount * d.TCMBME,2) else round(amount,2) end as montante_eur
# MAGIC   from
# MAGIC   (
# MAGIC     select * 
# MAGIC     from common_payments_occasionaltransactions.occasional_transaction
# MAGIC     where transaction_request_date between '2025-01-01' and '2025-12-31' 
# MAGIC     -- and transaction_detail_code in ('CDP', 'SDP', 'FXS') 
# MAGIC     and party_id <> '#N/A'
# MAGIC   ) a
# MAGIC   inner join
# MAGIC   ( -- define tipos de depósitos com base no BANKTELLER (700 Dep Numerario Balcao, 713 Dep Numerario SelBanking, 708 Compra de Moeda Estrangeira)
# MAGIC     select * 
# MAGIC     from common_referencedata_core.param_general_code_converter
# MAGIC     where data_date_part = '2026-02-09' 
# MAGIC     and source_code = 'BKT'
# MAGIC     and target_field = 'transaction_detail_code'
# MAGIC     and source_value in ('700', '713', '708') 
# MAGIC   ) b
# MAGIC   on a.transaction_detail_code = b.target_value
# MAGIC   left join
# MAGIC   ( -- tradução do código da moeda
# MAGIC     select * 
# MAGIC     from common_referencedata_core.reference_data_table
# MAGIC     where data_date_part = '2026-02-09'
# MAGIC     and data_table_code = '000206'
# MAGIC   ) c
# MAGIC   on a.currency_code = c.element_code
# MAGIC   left join
# MAGIC   (
# MAGIC     select * 
# MAGIC     from curated_internal_mainframe_cambios.cbt02_cambios 
# MAGIC     where CTBCAMB = 'F' 
# MAGIC     and cmarca = 'BT' 
# MAGIC     and zseqcamb = '99' 
# MAGIC   ) d
# MAGIC   on a.currency_code = d.cmoeda and a.data_date_part = d.data_date_part
# MAGIC ) a
# MAGIC group by party_id

# COMMAND ----------

# DBTITLE 1,Union de Indicadores
tbl_union = spark.sql(f"""
                      
select distinct 
    a.party_id, a.partenon_id, a.Tipo_Cliente, case when p.risco_dsc is null then 'B' else p.risco_dsc end as risco_dsc,
    case when b.econ_activity_category_code in ('64320','68322') or c.zcliente is not null then 'S' else 'N' end as centro_inter_colec_s_person_juridica,
    b.econ_activity_category_code, b.econ_activity_category_desc,
    c.CTIPSOC, c.DSC_TIPSOC,
    d.CPAIS_P as Nacionalidade, d.order_number as Ordem_Nacionalidade,
    case 
        when a.Tipo_Cliente in ('F', 'BEF')     then e.CPAIS_P
        when a.Tipo_Cliente = 'J'               then f.CPAIS_P
        end as Residencia_Principal,
    g.CPAIS_P as Sede,
    h.iclipep, h.Tipo_PEP as cargo_pep,
    case when i.cpersona is not null then 'S' else 'N' end as TOCPP,
    case when m.zcliente is not null then 'S' else 'N' end as ARI,
    j.employer_name, cast(coalesce(k.patrimonio, 0) as decimal(16,2)) as valor_patrimonio_liquido,
    case when l.party_id is not null then 'S' else 'N' end as org_s_fins_lucrativos,
    case when n.party_id is not null then 'S' else 'N' end as activ_area_risco_elevado,
    case 
        when n.party_id is not null and n.econ_activity_category_code in ('46190','47790', '47910', '82990') then 'Atividade leiloeira ou prestamista' 
        when n.party_id is not null and n.econ_activity_category_code in ('92001','92002') then 'Atividades associadas a jogo'
        when n.party_id is not null and n.econ_activity_category_code in ('93120','93192') then 'Atividades associadas a operações de alienação e aquisição de direitos sobre praticantes de atividades desportivas profissionais'
        when n.party_id is not null and n.econ_activity_category_code in ('24410','24450','32122','32123','46480','46820','49200','49410','50200','50400','51210') then 'Atividades de importação e exportação de diamantes ou pedras preciosas, ou de ouro ou outros metais preciosos'
        when n.party_id is not null and n.econ_activity_category_code in ('64310','64320','66120','66300','80011') then 'Atividades de transporte, tratamento e distribuição de fundo de valores'
        when n.party_id is not null and n.econ_activity_category_code in ('68110','68120','68200','68310','68321','68323','68324') then 'Atividades Imobiliárias exercidas por entidades não financeiras'
        when n.party_id is not null and n.econ_activity_category_code in ('47770','47783','47920') then 'Atividades relacionadas com comercio de arte ou antiguidades'
        when n.party_id is not null and n.econ_activity_category_code in ('84210','94110','94200','94910','94991','94992','94993','94994','94995') then 'Organizações sem fins lucrativos'
    else 'N' 
    end as activ_area_risco_elevado_grupo,
    case when o.sintra is not null then 'S' else 'N' end as estrutura_complexa
from clientes_alvo a
left join
    cae b
on a.party_id = b.party_id
left join
    socied_heranc_massa_insolvencia c
on cast(a.party_id as bigint) = cast(c.zcliente as bigint)
left join
    nac_fisicos d
on a.party_id = d.party_id
left join
    res_fisicos e
on a.party_id = e.party_id
left join
    res_juridicos f
on a.party_id = f.party_id
left join
    origin_juridicos g
on a.party_id = g.party_id
left join
    peps h
on a.party_id = h.zcliente
left join
    tocpp i
on concat(substr(a.partenon_id,1,1), CAST(CAST(substr(a.partenon_id,2,9) AS BIGINT) AS STRING)) = i.cpersona
left join
    entidade_patronal j
on a.party_id = j.party_id
left join
    patrimonio k
on a.party_id = k.zcliente
left join
    organiz_s_fins_lucrativos l
on a.party_id = l.party_id
left join
    aris m
on a.party_id = m.zcliente
left join atividades_risco_elevado n
on a.party_id = n.party_id
left join estruturas_complexas o
on cast(a.party_id as bigint) = o.sintra
left join risco p
on concat(substr(a.partenon_id,1,1), CAST(CAST(substr(a.partenon_id,2,9) AS BIGINT) AS STRING)) = p.customer_id

""")

tbl_union.createOrReplaceTempView("tbl_union")
tbl_union.display()

# COMMAND ----------

# DBTITLE 1,validações
# MAGIC %sql
# MAGIC -- diplicados
# MAGIC select party_id, count(distinct party_id) as Total
# MAGIC from tbl_union
# MAGIC where 1=1
# MAGIC group by party_id
# MAGIC having count(distinct party_id) > 1

# COMMAND ----------

# DBTITLE 1,Registo de BD
tbl_universo = (tbl_union.distinct())

## Registo de BD
# spark.sql("DROP TABLE IF EXISTS workbench_fcc.rpb25_universo_parties")
tbl_universo.write.format("delta").mode("overwrite").option("mergeSchema", "true").saveAsTable("workbench_fcc.rpb25_universo_parties")

print('Foram registados', tbl_universo.filter(col("Tipo_Cliente")=='F').count(), 'clientes fisicos.')
print('Foram registados', tbl_universo.filter(col("Tipo_Cliente")=='J').count(), 'clientes jurídicos.')
print('Foram registados', tbl_universo.filter(col("Tipo_Cliente")=='BEF').count(), 'beneficiários efectivos.')

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from workbench_fcc.rpb25_universo_parties
# MAGIC where ari