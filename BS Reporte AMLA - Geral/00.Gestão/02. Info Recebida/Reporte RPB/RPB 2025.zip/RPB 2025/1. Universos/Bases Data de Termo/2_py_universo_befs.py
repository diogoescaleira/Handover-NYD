# Databricks notebook source
# DBTITLE 1,Importação de Bibliotecas
#importar bibliotecas spark
from pyspark.sql import SparkSession
from pyspark.sql.functions import desc, countDistinct, col, when, min, max, months_between, trunc, datediff, current_date, greatest, date_sub

#iniciar uma sessão spark
sp = SparkSession.builder.appName("CustomerAnalysis").getOrCreate()

data_date_part = "'2025-12-31'"

print(data_date_part)

# COMMAND ----------

# DBTITLE 1,BEFs
tbl_befs = spark.sql(f"""
    select a.cpers, a.cpers_empresa, a.RLP_TIPO_RELAC, a.relacao
    from
    (
        select distinct cpers, cpers_empresa, RLP_TIPO_RELAC, relacao
        from
        (
            select
                concat(a.rlp_tipo_pers2, a.rlp_cod_pers2) as cpers,
                concat(a.rlp_tipo_pers1, a.rlp_cod_pers1) as cpers_empresa, RLP_TIPO_RELAC,
                des_relac as relacao
            from      
            (
                select *
                from curated_internal_mainframe_clientes.relac_persona
                where data_date_part = {data_date_part}
                and RLP_TIPO_RELAC in 
                ('A3','A4', '25', '26', '27')
            ) a    
        left join 
        (
            select * 
            from workbench_fcc.desc_relac_persona 
            where tip_dir = 'D'
        ) b
        on a.rlp_tipo_relac = b.cod_rel
        ) bef_1

        union all

        select distinct cpers, cpers_empresa, RLP_TIPO_RELAC, relacao
        from
        (
            select
                concat(a.rlp_tipo_pers2, a.rlp_cod_pers2) as cpers_empresa,
                concat(a.rlp_tipo_pers1, a.rlp_cod_pers1) as cpers, RLP_TIPO_RELAC,
                des_relac as relacao
            from      
            (
                select *
                from curated_internal_mainframe_clientes.relac_persona
                where data_date_part = {data_date_part}
                and RLP_TIPO_RELAC in 
                ('A3','A4', '25', '26', '27')
            ) a    
            left join 
            (
                select * 
                from workbench_fcc.desc_relac_persona 
                where tip_dir = 'D'
            ) b
            on a.rlp_tipo_relac = b.cod_rel
        ) bef_2
    ) a

""")

tbl_befs.createOrReplaceTempView("befs")
tbl_befs.count()

# COMMAND ----------

# DBTITLE 1,Uniformização dos BEFs
#Garantir que à esquerda temos fisicos e à direita temos as Empresas
#Garantir no fim que o cliente Empresa existe no universo do RPB

tbl_befs_final = spark.sql(f"""
                     
select distinct
  a.cpers, b.party_id, a.cpers_empresa, c.party_id as party_id_empresa, a.rlp_tipo_relac, a.relacao
from
(
  select cpers, cpers_empresa, rlp_tipo_relac, relacao
  from befs
  where cpers like 'F%'
  union all
  select cpers_empresa as cpers, cpers as cpers_empresa, rlp_tipo_relac, relacao
  from befs
  where cpers_empresa like 'F%'
) a
left join
(

    select zcligrupo_id, party_id, partenon_id, party_type_code
    from common_parties_core.party
    where 1=1 
    and data_date_part = {data_date_part}
) b
on a.cpers = b.partenon_id
left join
(

    select zcligrupo_id, party_id, partenon_id, party_type_code
    from common_parties_core.party
    where 1=1 
    and data_date_part = {data_date_part}
) c
on a.cpers_empresa = c.partenon_id
where exists (select * from workbench_fcc.rpb25_universo_contratos_relacoes d where c.party_id = d.party_id)

""")

tbl_befs_final.createOrReplaceTempView("befs_fin")
tbl_befs_final.count()

# COMMAND ----------

tbl_befs_final.display()

# COMMAND ----------

# DBTITLE 1,Registo BD
## Registo de BD
spark.sql("DROP TABLE IF EXISTS workbench_fcc.rpb25_universo_befs")
tbl_befs_final.write.format("delta").mode("overwrite").option("mergeSchema", "true").saveAsTable("workbench_fcc.rpb25_universo_befs")