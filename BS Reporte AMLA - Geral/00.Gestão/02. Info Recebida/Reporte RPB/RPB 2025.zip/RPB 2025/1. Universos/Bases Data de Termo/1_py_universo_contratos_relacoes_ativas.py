# Databricks notebook source
# DBTITLE 1,Variáveis
#importar bibliotecas spark
from pyspark.sql.functions import col

#declaração de variáveis
data_date_part = "'2025-12-31'"
data_fim_relacoes_aberturas = "'2025-12-31'"

print(data_date_part)

# COMMAND ----------

# DBTITLE 1,Group by Contratos Elegíveis
## Tipos de Contratos
tbl_contratos = spark.sql(f"""
                          
select a.common_table_name, count(*) as total
from common_contracts_core.contract a
inner join (
    select 
        *
    from production.common_contracts_core.contract_party_relationship
    where 
        data_date_part = {data_date_part}
        and contract_intervention_type_code = '1'   -- Titulares
) b
on a.contract_id = b.contract_id
where 1=1
and a.data_date_part = {data_date_part}
group by a.common_table_name
order by 2 desc

""")

tbl_contratos.display()


# COMMAND ----------

# DBTITLE 1,Contratos e Relações Elegíveis
## Obtenção de Contratos
## Exclui-se do âmbito os Produtos de Cartão de Refeição
## Exclui-se do âmbito os Contratos Cancelados
## Exclui-se clientes fusionados

tbl_contratos = spark.sql(f"""

select distinct a.common_table_name, a.contract_id, a.product_family_id, a.product_id, a.subproduct_id, concat(a.cbalcao, a.cnumecta) as cconta, a.zdeposit, a.ztitulo, a.zproposta
from common_contracts_core.contract a
where 1=1
and a.data_date_part = {data_date_part}
and concat(product_id,subproduct_id) not in ('025001','025002')     -- Exclusão de Produtos de Cartão de Refeição
order by a.contract_id

""")

## Obtenção de Relações
## Relações criadas no período de reporte
tbl_relacoes = spark.sql(f"""

select distinct contract_id, d.zcligrupo_id, d.party_id, d.partenon_id, d.party_type_code, TAYD91C0_GELEMTAB as tipo_interv, contract_intervention_order_num, relationship_start_date
from production.common_contracts_core.contract_party_relationship a
inner join (
  select *
  from curated_internal_mainframe_estruturais.TAT91_TABELAS b
  where 1=1
  and TAYD91C0_CTABELA = '007'
) b
on a.contract_intervention_type_code = b.TAYD91C0_CELEMTAB
and a.data_date_part = b.data_date_part
left join
(
  select *
  from common_parties_core.party_fusion
  where 1=1 
  and data_date_part = {data_date_part}
) c
on a.party_id = c.fusion_party_id
inner join
(
  select zcligrupo_id, party_id, partenon_id, party_type_code
  from common_parties_core.party
  where 1=1 
  and data_date_part = {data_date_part}
) d
on a.party_id = d.party_id
where a.data_date_part = {data_date_part}
and a.contract_intervention_type_code = '1'                           -- Apenas relação de Titulares
and a.relationship_start_date <= {data_fim_relacoes_aberturas}        -- Apenas relações criadas até 31-12-2025
and c.fusion_party_id is null                                         -- Para excluir clientes fusionados

""")

## Join Contratos com Relações
tbl_contrato_relacoes = tbl_contratos.alias("a") \
    .join(tbl_relacoes.alias("b"), col("a.contract_id") == col("b.contract_id"), "inner") \
    .select(
        col("a.common_table_name"),
        col("a.contract_id"),
        col("a.product_family_id"),
        col("a.product_id"),
        col("a.subproduct_id"),
        col("a.cconta"),
        col("a.zdeposit"),
        col("a.ztitulo"),
        col("a.zproposta"),
        col("b.zcligrupo_id"),
        col("b.party_id"),
        col("b.partenon_id"),
        col("b.party_type_code"),
        col("b.tipo_interv"),
        col("b.contract_intervention_order_num"),
        col("b.relationship_start_date")
        ).distinct()

#tbl_contratos.count()
#tbl_relacoes.count()
#tbl_contrato_relacoes.count()

print('Existem', tbl_contrato_relacoes.select("contract_id").distinct().count(), 'contratos elegíveis.')
print('Existem', tbl_contrato_relacoes.select("party_id").distinct().count(), 'titulares de contratos elegíveis.')

# COMMAND ----------

# DBTITLE 1,Filtro por Contas de Depósito à Ordem
 ## Obtenção de Depósitos à Ordem
 ## Contas abertas até ao período de reporte
tbl_contas_ordem = spark.sql(f"""

select distinct a.contract_id, a.product_family_id, a.product_id, a.subproduct_id, a.opening_date, a.contract_status_code, b.element_description as contract_status_DSC
from common_contracts_currentaccounts.current_account a
inner join (
    select * from common_referencedata_core.param_reference_data_table
    where data_table_code = '001'                                 -- Elementos para tradução
    and element_description not like '%CANCELLED%'                -- Exclusão de Contratos Cancelados
    and data_date_part = {data_date_part}
) b
on a.contract_status_code = b.element_code 
where 1=1
and a.data_date_part = {data_date_part}
and a.opening_date <= {data_fim_relacoes_aberturas}        -- Apenas contas abertas até 31-12-25
order by a.contract_id

""")


tbl_universo_do = tbl_contrato_relacoes.alias("a") \
    .join(tbl_contas_ordem.alias("b"), col("a.contract_id") == col("b.contract_id"), "inner") \
    .select(
        col("a.common_table_name"),
        col("a.contract_id"),
        col("a.product_family_id"),
        col("a.product_id"),
        col("a.subproduct_id"),
        col("a.cconta"),
        col("a.zdeposit"),
        col("a.ztitulo"),
        col("a.zproposta"),
        col("b.contract_status_DSC"),
        col("b.opening_date"),
        col("a.zcligrupo_id"),
        col("a.party_id"),
        col("a.partenon_id"),
        col("a.party_type_code"),
        col("a.tipo_interv"),
        col("a.contract_intervention_order_num"),
        col("a.relationship_start_date")
        ).distinct()
    
#tbl_contas_ordem.count()
#tbl_universo_do.count()

print('Existem', tbl_universo_do.select("contract_id").distinct().count(), 'contratos DO elegíveis.')
print('Existem', tbl_universo_do.select("party_id").distinct().count(), 'titulares de contratos DO elegíveis.')

tbl_universo_do.display()

# COMMAND ----------

# DBTITLE 1,Registo de BD
## Union de DFs
tbl_universo_all = (
    tbl_universo_do
    .distinct()
)

## Registo de BD
spark.sql("DROP TABLE IF EXISTS wbpbcdb.rpb25_universo_contratos_relacoes")
tbl_universo_all.write.format("delta").mode("overwrite").option("mergeSchema", "true").saveAsTable("workbench_fcc.rpb25_universo_contratos_relacoes")

print('Foram registados', tbl_universo_all.count(), 'contratos/relações. Correspondentes a', tbl_universo_all.select("party_id").distinct().count(), 'titulares.')

# COMMAND ----------

# DBTITLE 1,Validação de BD
# MAGIC %sql
# MAGIC select contract_id, count(*)
# MAGIC from workbench_fcc.rpb25_universo_contratos_relacoes
# MAGIC group by 1
# MAGIC having count(*) > 1

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from workbench_fcc.rpb25_universo_contratos_relacoes
# MAGIC where contract_id = '000001444906001000000000000000'