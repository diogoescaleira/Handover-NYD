# Databricks notebook source
# DBTITLE 1,Variáveis
#importar bibliotecas spark
from pyspark.sql import functions as F


# COMMAND ----------

# DBTITLE 1,clientes distintos do período de ref
## Obtenção de Contratos e Relações Elegíveis
## Exclui-se do âmbito os Produtos de Cartão de Refeição
## Exclui-se do âmbito Factoring e CPP

tbl_cli_contas_peri = spark.sql(f"""

select distinct c.cconta, a.party_id, partenon_id, concat('TOT', substr(partenon_id,1,1), cast(substr(partenon_id,2,10)as int)) as customer_id_final
from(
    select * from(    
        select contract_id, party_id, row_number() over(partition by contract_id, party_id order by max_data_date_part desc) as n
        from(
            select trim(contract_id) as contract_id, party_id, contract_intervention_type_code, contract_intervention_order_num, relationship_start_date, max(data_date_part) as max_data_date_part
            from production.common_contracts_core.contract_party_relationship 
            where data_date_part between '2025-01-01' and '2025-12-31'
            group by trim(contract_id), party_id, contract_intervention_type_code, contract_intervention_order_num, relationship_start_date
        )
    )
    where n = 1
) a
inner join(
    select * from(
        select *, row_number() over (partition by contract_id, cconta order by data_max_conta desc) as n
        from(
            select distinct common_table_name, trim(contract_id) as contract_id, concat(cbalcao, cnumecta) as cconta, max(data_date_part) data_max_conta
            from common_contracts_core.contract
            where 1=1
            and data_date_part between '2025-01-01' and '2025-12-31'
            and concat(product_id, subproduct_id) not in ('025001','025002')     -- Exclusão de Produtos de Cartão de Refeição
            and product_family_id <> 'FAC'
            and product_family_id <> 'CPP'
            group by common_table_name, trim(contract_id), concat(cbalcao, cnumecta)
        )
    )
    where n = 1 
    and cconta <> '' and cconta <> ' ' and cconta <> '6416'
)c
on trim(a.contract_id) = c.contract_id
inner join
(
    select party_id, partenon_id, max(data_date_part) as max_data_date_part
    from common_parties_core.party
    where 1=1 
    and data_date_part between '2025-01-01' and '2025-12-31'
    group by party_id, partenon_id
) d
on a.party_id = d.party_id
inner join(
    select distinct trim(contract_id) contract_id
    from common_contracts_currentaccounts.current_account
    where 1=1
    and data_date_part between '2025-01-01' and '2025-12-31'
    and contract_status_code not in ('CND','CWD','CAN') -- excluir contas canceladas
) e
on a.contract_id = e.contract_id

""")

result = tbl_cli_contas_peri.select(
    F.col('party_id'),
    F.col('partenon_id'),
    F.col('customer_id_final'),
).distinct()

result.createOrReplaceTempView("clientes_ref")

# COMMAND ----------

# DBTITLE 1,Juntar Base BEFs
befs = spark.sql(f"""
    select party_id, concat(substr(cpers,1,1), 
    cast(substr(cpers,2,10)as int)) as partenon_id,
    concat('TOT', substr(cpers,1,1), cast(substr(cpers,2,10)as int)) as customer_id_final, 
    'BEF' as Tipo_Cliente 
    from workbench_fcc.rpb25_universo_befs_periodo_ref
""")

base = spark.sql(f"""
    select *, substr(partenon_id, 1, 1) as Tipo_Cliente
    from clientes_ref
""")

base_cli = base.union(befs).distinct()

# base_cli.display()

# COMMAND ----------

# DBTITLE 1,criação tabela base só clientes
spark.sql("DROP TABLE IF EXISTS workbench_fcc.rpb25_universo_parties_peri_ref")
base_cli.write.format("delta").mode("overwrite").option("mergeSchema", "true").saveAsTable("workbench_fcc.rpb25_universo_parties_peri_ref")

# COMMAND ----------

# DBTITLE 1,clientes ativos rpb 2024
cli_2024 = spark.sql(f"""
    select * from workbench_fcc.clientes_ativos_rpb_2024
""")

# cli_2024.count()

# COMMAND ----------

# DBTITLE 1,base clientes
base_cli = spark.sql(f"""
    select * from workbench_fcc.rpb25_universo_parties_peri_ref
""")



# COMMAND ----------

# DBTITLE 1,Novas relações 2025
novas_rel_25 = base_cli.join(cli_2024, F.col('customer_id_final') == F.col('customer_id'), how='leftanti')

# novas_rel_25.select('customer_id_final').count()

# COMMAND ----------

# DBTITLE 1,Flag Nova Relação em 2025
a = base_cli.alias("a")
b = novas_rel_25.alias("b")

flag_nova_rel = (
    a.join(
        b.select("party_id", "partenon_id", "customer_id_final").dropDuplicates().alias("b"),
        on=["party_id", "partenon_id", "customer_id_final"],
        how="left"
    )
    .withColumn("nova_rel", F.when(F.col("b.party_id").isNotNull(), F.lit("S")).otherwise(F.lit("N")))
    .select("a.*", "nova_rel")
)

flag_nova_rel.count()

# COMMAND ----------

# DBTITLE 1,Residência
tbl_res_fisicos = spark.sql(f"""

select distinct a.party_id, b.CPAIS_P from(                          
    select *
    from common_parties_individuals.individual_address 
    where data_date_part between '2025-01-01' and '2025-12-31'
    and address_type_code = '01' 
)a
left join
(
    select *
    from curated_internal_mainframe_estruturais.tat03_paises
    where data_date_part = '2025-12-31'
) b 
on a.country_code = b.CPAIS_S
inner join(
    select distinct party_id, max(data_date_part) max_data
    from common_parties_individuals.individual_address  
    where data_date_part between '2025-01-01' and '2025-12-31'
    and address_type_code = '01' 
    group by party_id
) c
on a.party_id = c.party_id and a.data_date_part = c.max_data

""")

tbl_res_juridicos = spark.sql(f"""
     
select distinct a.party_id, b.CPAIS_P from(                          
    select *
    from common_parties_entities.entity_address  
    where data_date_part between '2025-01-01' and '2025-12-31'
    and address_type_code = '01' 
)a
left join
(
    select *
    from curated_internal_mainframe_estruturais.tat03_paises
    where data_date_part = '2025-12-31'
) b 
on a.country_code = b.CPAIS_S
inner join(
    select distinct party_id, max(data_date_part) max_data
    from common_parties_entities.entity_address   
    where data_date_part between '2025-01-01' and '2025-12-31'
    and address_type_code = '01' 
    group by party_id
) c
on a.party_id = c.party_id and a.data_date_part = c.max_data

""")

union_resi = tbl_res_fisicos.union(tbl_res_juridicos)

c = flag_nova_rel.alias("c")
d = union_resi.alias("d")

flag_residencia = (
    c.join(
        d.select("party_id", F.col("CPAIS_P").alias("Residencia_Principal")).dropDuplicates(["party_id"]).alias("d"),
        on="party_id",
        how="left"
    )
    .select("c.*", "Residencia_Principal")
)

flag_residencia.count()

# COMMAND ----------

# DBTITLE 1,Sede
tbl_origin_juridicos = spark.sql(f"""
       
select distinct a.party_id, b.CPAIS_P from(                          
    select *
    from common_parties_entities.entity  
    where data_date_part between '2025-01-01' and '2025-12-31'
)a
left join
(
    select *
    from curated_internal_mainframe_estruturais.tat03_paises
    where data_date_part = '2025-12-31'
) b 
on a.origin_country_code = b.CPAIS_S
inner join(
    select distinct party_id, max(data_date_part) max_data
    from common_parties_entities.entity   
    where data_date_part between '2025-01-01' and '2025-12-31'
    group by party_id
) c
on a.party_id = c.party_id and a.data_date_part = c.max_data

""")

a = flag_residencia.alias("a")
b = tbl_origin_juridicos.alias("b")

flag_sede = (
    a.join(
        b.select("party_id", F.col("CPAIS_P").alias("Sede")).dropDuplicates(["party_id"]).alias("b"),
        on="party_id",
        how="left"
    )
    .select("a.*", "Sede")
)

flag_sede.count()

# COMMAND ----------

# DBTITLE 1,CAE + Centros Interesse
tbl_cae = spark.sql(f"""
select * from(                    
    select distinct a.party_id, a.industry_classific_system_code, a.order_number, a.econ_activity_category_code, b.TAYD91C0_GELEMTAB as econ_activity_category_desc,
        row_number() over(partition by a.party_id order by a.max_data desc) as n
    from
    ( 
        select party_id, industry_classific_system_code, order_number, econ_activity_category_code, max(data_date_part) max_data  
        from common_parties_entities.entity_economic_activity 
        where data_date_part between '2025-01-01' and '2025-12-31'
        group by party_id, industry_classific_system_code, order_number, econ_activity_category_code
        union all
        select party_id, industry_classific_system_code, order_number, econ_activity_category_code, max(data_date_part) max_data 
        from common_parties_individuals.individual_economic_activity 
        where data_date_part between '2025-01-01' and '2025-12-31'
        group by party_id, industry_classific_system_code, order_number, econ_activity_category_code
    ) a
    left join
    (
    select * 
    from curated_internal_mainframe_estruturais.tat91_tabelas 
    where data_date_part = '2025-12-31'
    and TAYD91C0_CTABELA = '154'
    ) b
    on  a.econ_activity_category_code = b.TAYD91C0_CELEMTAB
)
where n = 1

""")

tbl_tipo_soc = spark.sql(f"""
                  
select distinct a.ZCLIENTE, a.NOMER, a.CTIPSOC, b.TAYD91C0_GELEMTAB as DSC_TIPSOC, max(a.data_date_part) max_data
from curated_internal_mainframe_clientes.clt45_fcli a
left join
(
    select * 
    from curated_internal_mainframe_estruturais.tat91_tabelas 
    where TAYD91C0_CTABELA = 'J90' 
    and data_date_part = '2025-12-31'
) b
on a.CTIPSOC = b.TAYD91C0_CELEMTAB
where a.data_date_part between '2025-01-01' and '2025-12-31'
and a.CTIPSOC in (18, 19)
group by a.ZCLIENTE, a.NOMER, a.CTIPSOC, b.TAYD91C0_GELEMTAB

""")

a = flag_sede.alias("a")
b = tbl_cae.alias("b")
c = tbl_tipo_soc.alias("c")

flag_centros_intercolec_s_person_juridica = (
    a.join(
        b.select("party_id", "econ_activity_category_code").alias("b"),
        on="party_id",
        how="left"
    )
    .join(
        c.select(F.col("ZCLIENTE").alias("zcliente")).dropDuplicates(["zcliente"]).alias("c"),
        F.col("a.party_id") == F.col("c.zcliente"),
        "left"
    )
    .withColumn(
        "centro_inter_colec_s_person_juridica",
        F.when(
            (F.col("b.econ_activity_category_code").isin("64320", "68322")) | (F.col("c.zcliente").isNotNull()),
            F.lit("S")
        ).otherwise(F.lit("N"))
    )
    .select("a.*", "centro_inter_colec_s_person_juridica")
)


flag_centros_intercolec_s_person_juridica.count()
# flag_centros_intercolec_s_person_juridica.filter(F.col("centro_inter_colec_s_person_juridica") == 'S').display()


# COMMAND ----------

# DBTITLE 1,Nacionalidade
tbl_nac_fisicos = spark.sql(f"""
                          
select distinct 
    a.party_id,
    concat_ws(',', collect_set(a.order_number)) AS order_number,
    concat_ws(',', collect_set(a.country_code)) AS country_code,
    concat_ws(',', collect_set(b.CPAIS_P)) AS CPAIS_P,
    max(a.data_date_part) as max_data
from common_parties_individuals.individual_citizenship a
left join
(
    select *
    from curated_internal_mainframe_estruturais.tat03_paises
    where data_date_part = '2025-12-31' 
) b 
on a.country_code = b.CPAIS_S
where a.data_date_part between '2025-01-01' and '2025-12-31'
group by a.party_id
""")

a = flag_centros_intercolec_s_person_juridica.alias("a")
b = tbl_nac_fisicos.alias("b")

flag_nacionalidade = (   
    a.join(
        b.select("party_id", F.col("CPAIS_P").alias("Nacionalidade"))
            .dropDuplicates(["party_id"])
            .alias("b"),
        on="party_id",
        how="left"
    )
    .select("a.*", "Nacionalidade")
)

flag_nacionalidade.count()


# COMMAND ----------

# DBTITLE 1,Flag Risco Alto
tbl_risco_alto = spark.sql(f"""                      
select a.* from(
    select distinct customer_id, assigned_risk_id, 
        case when assigned_risk_id in ('1000','1003','1005') then 'A'
        when assigned_risk_id in ('1001','1004','1007') then 'M'
        when assigned_risk_id in ('1002','1006') then 'B' else 'B' end as risco_dsc,
        SCORE_TIMESTAMP, date(SCORE_TIMESTAMP) data_date_part
    from curated_internal_norkom.cdd_customer_score_history
    where data_date_part = '2025-12-31' and (date(SCORE_TIMESTAMP) between '2025-01-01' and '2025-03-01' or date(SCORE_TIMESTAMP) between '2025-03-31' and '2025-12-31') -- exclusão do mês de março por erros do cra
) a
inner join(
    select customer_id, max(SCORE_TIMESTAMP) as max_score, date(SCORE_TIMESTAMP) data_score
    from curated_internal_norkom.cdd_customer_score_history
    where data_date_part = '2025-12-31' and (date(SCORE_TIMESTAMP) between '2025-01-01' and '2025-03-01' or date(SCORE_TIMESTAMP) between '2025-03-31' and '2025-12-31') -- exclusão do mês de março por erros do cra
    group by id, customer_id, date(SCORE_TIMESTAMP) 
) b
on a.customer_id = b.customer_id and a.SCORE_TIMESTAMP = b.max_score and a.data_date_part = b.data_score
""")

aux = tbl_risco_alto.filter(F.col('risco_dsc') == 'A').distinct()

a = flag_nacionalidade.alias("a")
b = aux.alias("b")

flag_risco_alto = (
    a.join(
        b.select("customer_id", "risco_dsc").dropDuplicates().alias("b"),
        F.col("a.customer_id_final") == F.col("b.customer_id"),
        how="left"
    )
    .withColumn("risco_alto", F.when(F.col("b.customer_id").isNotNull(), F.lit("S")).otherwise(F.lit("N")))
    .select("a.*", "risco_alto")
)

flag_risco_alto.count()


# COMMAND ----------

# DBTITLE 1,Risco Atual
tbl_risco = spark.sql(f"""                      
select distinct customer_id, assigned_risk_id, 
    case when assigned_risk_id in ('1000','1003','1005') then 'A'
    when assigned_risk_id in ('1001','1004','1007') then 'M'
    when assigned_risk_id in ('1002','1006') then 'B' else 'B' end as risco_dsc,
    SCORE_TIMESTAMP, data_date_part
from curated_internal_norkom.cdd_customer_score
where data_date_part = '2025-12-31'
""")

a = flag_risco_alto.alias("a")
b = tbl_risco.alias("b")

flag_risco = (
    a.join(
        b.select("customer_id", F.col("risco_dsc").alias("risco_atual"))
        .dropDuplicates().alias("b"),
        F.col("a.customer_id_final") == F.col("b.customer_id"),
        how="left"
    )
    .select("a.*", "risco_atual")
)

flag_risco.count()

# COMMAND ----------

# DBTITLE 1,Naturalidade
tbl_birth_fisicos = spark.sql(f"""
                          
select distinct a.party_id, a.birth_country_code as naturalidade, b.CPAIS_P, max(a.data_date_part) max_data
from common_parties_individuals.individual a
left join
(
    select *
    from curated_internal_mainframe_estruturais.tat03_paises
    where data_date_part = '2025-12-31' 
) b 
on a.birth_country_code = b.CPAIS_S
where a.data_date_part between '2025-01-01' and '2025-12-31'
group by a.party_id, a.birth_country_code, b.CPAIS_P

""")

tbl_origin_juridicos = spark.sql(f"""
       
select distinct a.party_id, a.origin_country_code as naturalidade, b.CPAIS_P, max(a.data_date_part) max_data
from common_parties_entities.entity a
left join
(
    select *
    from curated_internal_mainframe_estruturais.tat03_paises
    where data_date_part = '2025-12-31'   
) b 
on a.origin_country_code = b.CPAIS_S
where a.data_date_part between '2025-01-01' and '2025-12-31'
group by a.party_id, a.origin_country_code, b.CPAIS_P

""")

union_orig = tbl_birth_fisicos.union(tbl_origin_juridicos)

c = flag_risco.alias("c")
d = union_orig.alias("d")

flag_orig = (
    c.join(
        d.select("party_id", F.col("CPAIS_P").alias("Naturalidade")).dropDuplicates(["party_id"]).alias("d"),
        on="party_id",
        how="left"
    )
    .select("c.*", "Naturalidade")
)

flag_orig.count()


# COMMAND ----------

# DBTITLE 1,criação da tabela segmentada
spark.sql("DROP TABLE IF EXISTS workbench_fcc.rpb25_universo_dever_id_dil")
flag_orig.write.format("delta").mode("overwrite").option("mergeSchema", "true").saveAsTable("workbench_fcc.rpb25_universo_dever_id_dil")

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(distinct party_id), count(*) from workbench_fcc.rpb25_universo_parties_peri_ref

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(distinct party_id), count(*) from workbench_fcc.rpb25_universo_dever_id_dil

# COMMAND ----------

base_cli.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from 
# MAGIC workbench_fcc.rpb25_universo_dever_id_dil
# MAGIC