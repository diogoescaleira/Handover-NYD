# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import SparkSession


# COMMAND ----------

#declaração de variáveis
data_date_part_init = "'2025-01-01'"
data_date_part_fin = "'2025-12-31'"

print(data_date_part_init)
print(data_date_part_fin)

# COMMAND ----------

spark = SparkSession.builder \
    .appName("trf_fundos_cli_rpb25") \
    .getOrCreate()

# COMMAND ----------

base_cli = spark.sql(f"""
    select distinct customer_id_final, 
           case when direcao = 'R' then cast(party_id_ben as bigint) else cast(party_id_ord as bigint) end as party_id,
           substr(customer_id_final,4,1) as Tipo_Cliente
    from workbench_fcc.rpb25_transf_fundos

""")

base_cli.display()
base_cli.createOrReplaceTempView("base_cli")

# COMMAND ----------

# DBTITLE 1,Residência
tbl_res_fisicos = spark.sql(f"""

select distinct a.party_id, coalesce(b.CPAIS_P, 'PT') CPAIS_P from(                          
    select cast(party_id as bigint) party_id, country_code, data_date_part
    from common_parties_individuals.individual_address 
    where data_date_part between {data_date_part_init} and {data_date_part_fin}
    and address_type_code = '01' 
)a
left join
(
    select *
    from curated_internal_mainframe_estruturais.tat03_paises
    where data_date_part = {data_date_part_fin}  
) b 
on a.country_code = b.CPAIS_S
inner join(
    select distinct cast(party_id as bigint) party_id, max(data_date_part) max_data
    from common_parties_individuals.individual_address  
    where data_date_part between {data_date_part_init} and {data_date_part_fin}
    and address_type_code = '01' 
    group by cast(party_id as bigint)
) c
on a.party_id = c.party_id and a.data_date_part = c.max_data

""")

tbl_res_juridicos = spark.sql(f"""
     
select distinct a.party_id, coalesce(b.CPAIS_P, 'PT') CPAIS_P from(                          
    select cast(party_id as bigint) party_id, country_code, data_date_part
    from common_parties_entities.entity_address  
    where data_date_part between {data_date_part_init} and {data_date_part_fin}
    and address_type_code = '01' 
)a
left join
(
    select *
    from curated_internal_mainframe_estruturais.tat03_paises
    where data_date_part = {data_date_part_fin}  
) b 
on a.country_code = b.CPAIS_S
inner join(
    select distinct cast(party_id as bigint) party_id, max(data_date_part) max_data
    from common_parties_entities.entity_address   
    where data_date_part between {data_date_part_init} and {data_date_part_fin}
    and address_type_code = '01' 
    group by cast(party_id as bigint)
) c
on a.party_id = c.party_id and a.data_date_part = c.max_data

""")

tbl_res_fisicos.createOrReplaceTempView("res_fisicos")
tbl_res_juridicos.createOrReplaceTempView("res_juridicos")
#tbl_res_fisicos.filter(col("party_id") == '7402308104').display()
#tbl_res_juridicos.display()
#tbl_res_fisicos.count()
#tbl_res_juridicos.count()

print('Existem',tbl_res_fisicos.count(), 'clientes singulares e ', tbl_res_juridicos.count(), 'clientes juridicos.')

# COMMAND ----------

# DBTITLE 1,Sede
tbl_origin_juridicos = spark.sql(f"""
       
select distinct a.party_id, coalesce(b.CPAIS_P, 'PT') CPAIS_P from(                          
    select cast(party_id as bigint) party_id, origin_country_code, data_date_part
    from common_parties_entities.entity  
    where data_date_part between {data_date_part_init} and {data_date_part_fin}
)a
left join
(
    select *
    from curated_internal_mainframe_estruturais.tat03_paises
    where data_date_part = {data_date_part_fin}  
) b 
on a.origin_country_code = b.CPAIS_S
inner join(
    select distinct cast(party_id as bigint) party_id, max(data_date_part) max_data
    from common_parties_entities.entity   
    where data_date_part between {data_date_part_init} and {data_date_part_fin}
    group by cast(party_id as bigint)
) c
on a.party_id = c.party_id and a.data_date_part = c.max_data

""")

tbl_origin_juridicos.createOrReplaceTempView("origin_juridicos")
#tbl_birth_fisicos.filter(col("party_id") == '7402308104').display()
#tbl_origin_juridicos.display()

# COMMAND ----------

# DBTITLE 1,PEP
aux_ind_pep = spark.sql(f"""

select  distinct zcliente, iclipep, case when CCARPEP = '17' then 'PROXIMO FAMILIA' when CCARPEP = '18' then 'PESSOA RECONH ESTRIT ASSOC' else 'PEP' end as Tipo_PEP
from  	curated_internal_mainframe_clientes.clt45_fcli
where	data_date_part between {data_date_part_init} and {data_date_part_fin}
and 	iclipep <> 'N' and iclipep <> ''

""")

aux_ind_pep.createOrReplaceTempView("peps")
#aux_ind_pep.display()
aux_ind_pep.count()

# COMMAND ----------

# DBTITLE 1,Entidade Patronal
tbl_entid_patron = spark.sql(f"""
                          
select distinct cast(a.party_id as bigint) party_id, a.employer_name
from common_parties_individuals.individual a
where a.data_date_part = {data_date_part_fin}

""")

tbl_entid_patron.createOrReplaceTempView("entidade_patronal")
#tbl_entid_patron.display()
tbl_entid_patron.count()

# COMMAND ----------

# DBTITLE 1,Património Líquido
tbl_patrimonio = spark.sql(f"""
select  zcliente, cast(sum(Saldo_PASSIVO) - sum(Saldo_ACTIVO) as double) as Patrimonio 
from 
(
    select  
            concat(ct.ckbalcao,ct.cknumcta) AS num_conta_15d, zcliente,
            sum(case when nivel_2 = 'P' then ct.c001 end) as Saldo_PASSIVO,
            sum(case when nivel_2 = 'A' then ct.c001 end) as Saldo_ACTIVO,
            sum(ct.c001) as VN
    from    curated_internal_datalake_ctools.ct209_rent_kpm as ct 
    left join 
    (
            select  distinct nivel_1, nivel_2, nivel_3, nivel_12 
            from    curated_internal_datalake_ctools.ct011_dim_hier 
            where   ref_date = {data_date_part_fin}
    ) AS hier 
    on      hier.nivel_12=ct.ckmetamis 
    where   ct.ref_Date = {data_date_part_fin}
    group by 
            concat(ct.ckbalcao, ct.cknumcta), zcliente
) a group by zcliente
""")

tbl_patrimonio.createOrReplaceTempView("patrimonio")
#tbl_patrimonio.display()
#tbl_patrimonio.filter(col("zcliente")=='7402357521').display()
tbl_patrimonio.count()

# COMMAND ----------

# DBTITLE 1,ONGs
tbl_org_s_fins_lucra = spark.sql(f"""
                          
select distinct a.party_id, a.industry_classific_system_code, a.order_number, a.econ_activity_category_code, b.TAYD91C0_GELEMTAB as econ_activity_category_desc
from
( 
    select cast(party_id as bigint) party_id, industry_classific_system_code, order_number, econ_activity_category_code, data_date_part
    from common_parties_entities.entity_economic_activity 
    where data_date_part between {data_date_part_init} and {data_date_part_fin}
    and econ_activity_category_code in ('94991','94992','94993','94994','94995','94200','94110','94910','84210')
    union all
    select cast(party_id as bigint) party_id, industry_classific_system_code, order_number, econ_activity_category_code, data_date_part
    from common_parties_individuals.individual_economic_activity 
    where data_date_part between {data_date_part_init} and {data_date_part_fin}
    and econ_activity_category_code in ('94991','94992','94993','94994','94995','94200','94110','94910','84210')
) a
left join
(
  select * 
  from curated_internal_mainframe_estruturais.tat91_tabelas 
  where data_date_part = {data_date_part_fin}
  and TAYD91C0_CTABELA = '154'
) b
on  a.econ_activity_category_code = b.TAYD91C0_CELEMTAB
inner join(
    select distinct cast(party_id as bigint) party_id, max(data_date_part) max_data
    from common_parties_entities.entity_economic_activity  
    where data_date_part between {data_date_part_init} and {data_date_part_fin}
    group by cast(party_id as bigint)
    union all
    select distinct cast(party_id as bigint) party_id, max(data_date_part) max_data
    from common_parties_individuals.individual_economic_activity  
    where data_date_part between {data_date_part_init} and {data_date_part_fin}
    group by cast(party_id as bigint)
) c
on a.party_id = c.party_id and a.data_date_part = c.max_data


""")

tbl_org_s_fins_lucra.createOrReplaceTempView("organiz_s_fins_lucrativos")
#tbl_org_s_fins_lucra.display()
tbl_org_s_fins_lucra.count()

# COMMAND ----------

# DBTITLE 1,Atividades Risco Elevado
tbl_ativid_risco_elevado = spark.sql(f"""
                          
select distinct a.party_id, a.industry_classific_system_code, a.order_number, a.econ_activity_category_code, b.TAYD91C0_GELEMTAB as econ_activity_category_desc
from
( 
    select cast(party_id as bigint) party_id, industry_classific_system_code, order_number, econ_activity_category_code, data_date_part 
    from common_parties_entities.entity_economic_activity 
    where data_date_part between {data_date_part_init} and {data_date_part_fin}
    and econ_activity_category_code in ('24410','24450','32122','32123','46190','46480','46820','47770','47783','47790','47910','47920','49200','49410','50200','50400','51210','64310','64320','66120','66300','68110','68120','68200','68310','68321','68323','68324','80011','82990','84210','92001','92002','93120','93192','94110','94200','94910','94991','94992','94993','94994','94995')
    union all
    select cast(party_id as bigint) party_id, industry_classific_system_code, order_number, econ_activity_category_code, data_date_part 
    from common_parties_individuals.individual_economic_activity 
    where data_date_part between {data_date_part_init} and {data_date_part_fin}
    and econ_activity_category_code in ('24410','24450','32122','32123','46190','46480','46820','47770','47783','47790','47910','47920','49200','49410','50200','50400','51210','64310','64320','66120','66300','68110','68120','68200','68310','68321','68323','68324','80011','82990','84210','92001','92002','93120','93192','94110','94200','94910','94991','94992','94993','94994','94995')
) a
left join
(
  select * 
  from curated_internal_mainframe_estruturais.tat91_tabelas 
  where data_date_part = {data_date_part_fin}
  and TAYD91C0_CTABELA = '154'
) b
on  a.econ_activity_category_code = b.TAYD91C0_CELEMTAB
inner join(
    select distinct cast(party_id as bigint) party_id, max(data_date_part) max_data
    from common_parties_entities.entity_economic_activity  
    where data_date_part between {data_date_part_init} and {data_date_part_fin}
    group by cast(party_id as bigint)
    union all
    select distinct cast(party_id as bigint) party_id, max(data_date_part) max_data
    from common_parties_individuals.individual_economic_activity  
    where data_date_part between {data_date_part_init} and {data_date_part_fin}
    group by cast(party_id as bigint)
) c
on a.party_id = c.party_id and a.data_date_part = c.max_data

""")

tbl_ativid_risco_elevado.createOrReplaceTempView("atividades_risco_elevado")
#tbl_ativid_risco_elevado.display()
tbl_ativid_risco_elevado.count()

# COMMAND ----------

# DBTITLE 1,ARIs
tbl_aris = spark.sql(f"""
                     
select ZCLIENTE, DTINICIO
from (
    select *
    from curated_internal_mainframe_clientes.clt44_infadic
    where 1=1
    and data_date_part between {data_date_part_init} and {data_date_part_fin}
    and INDICADOR = 'IAR' and DESCRICAO = 'S'
    and DTFIM > {data_date_part_fin}
) a

""")

tbl_aris.createOrReplaceTempView("aris")
tbl_aris.count()

# COMMAND ----------

# DBTITLE 1,Estruturas Complexas
tbl_complexas = spark.sql(f"""
                     
select distinct *
from (
    select *
    from workbench_fcc.rpb25_estruturas_complexas
    where 1=1
    and CTIPPRO in ('2', '1')
) a

""")

tbl_complexas.createOrReplaceTempView("estruturas_complexas")
tbl_complexas.count()
#tbl_complexas.display()

# COMMAND ----------

# DBTITLE 1,centro_inter_colec_s_person_juridica
tbl_cae = spark.sql(f"""
select * from(                    
    select distinct a.party_id, a.industry_classific_system_code, a.order_number, a.econ_activity_category_code, b.TAYD91C0_GELEMTAB as econ_activity_category_desc,
        row_number() over(partition by a.party_id order by a.max_data desc) as n
    from
    ( 
        select cast(party_id as bigint) party_id, industry_classific_system_code, order_number, econ_activity_category_code, max(data_date_part) max_data  
        from common_parties_entities.entity_economic_activity 
        where data_date_part between '2025-01-01' and '2025-12-31'
        group by cast(party_id as bigint), industry_classific_system_code, order_number, econ_activity_category_code
        union all
        select cast(party_id as bigint) party_id, industry_classific_system_code, order_number, econ_activity_category_code, max(data_date_part) max_data 
        from common_parties_individuals.individual_economic_activity 
        where data_date_part between '2025-01-01' and '2025-12-31'
        group by cast(party_id as bigint), industry_classific_system_code, order_number, econ_activity_category_code
    ) a
    left join
    (
    select * 
    from curated_internal_mainframe_estruturais.tat91_tabelas 
    where data_date_part = '2025-12-31'
    and TAYD91C0_CTABELA = '154'
    ) b
    on  a.econ_activity_category_code = b.TAYD91C0_CELEMTAB
)
where n = 1

""")

tbl_tipo_soc = spark.sql(f"""
                  
select distinct a.ZCLIENTE, a.NOMER, a.CTIPSOC, b.TAYD91C0_GELEMTAB as DSC_TIPSOC, max(a.data_date_part) max_data
from curated_internal_mainframe_clientes.clt45_fcli a
left join
(
    select * 
    from curated_internal_mainframe_estruturais.tat91_tabelas 
    where TAYD91C0_CTABELA = 'J90' 
    and data_date_part = '2025-12-31'
) b
on a.CTIPSOC = b.TAYD91C0_CELEMTAB
where a.data_date_part between '2025-01-01' and '2025-12-31'
and a.CTIPSOC in (18, 19)
group by a.ZCLIENTE, a.NOMER, a.CTIPSOC, b.TAYD91C0_GELEMTAB

""")

tbl_cae.createOrReplaceTempView("cae")
tbl_tipo_soc.createOrReplaceTempView("socied_heranc_massa_insolvencia")


# COMMAND ----------

# DBTITLE 1,Nacionalidade
tbl_nac_fisicos = spark.sql(f"""
                          
select distinct 
    cast(a.party_id as bigint) party_id,
    concat_ws(',', collect_set(a.order_number)) AS order_number,
    concat_ws(',', collect_set(a.country_code)) AS country_code,
    coalesce(concat_ws(',', collect_set(b.CPAIS_P)), 'PT') AS CPAIS_P,
    max(a.data_date_part) as max_data
from common_parties_individuals.individual_citizenship a
left join
(
    select *
    from curated_internal_mainframe_estruturais.tat03_paises
    where data_date_part = '2025-12-31' 
) b 
on a.country_code = b.CPAIS_S
where a.data_date_part between '2025-01-01' and '2025-12-31'
group by cast(a.party_id as bigint)
""")

tbl_nac_fisicos.createOrReplaceTempView("nac_fisicos")

# COMMAND ----------

tbl_union = spark.sql(f"""
                      
select distinct 
    a.party_id, a.customer_id_final, a.Tipo_Cliente, 
    case 
        when a.Tipo_Cliente in ('F', 'BEF')     then coalesce(e.CPAIS_P, 'PT')
        when a.Tipo_Cliente = 'J'               then coalesce(f.CPAIS_P, 'PT')
    else 'PT'
    end as Residencia_Principal,
    coalesce(d.CPAIS_P, 'PT') as Nacionalidade, d.order_number as Ordem_Nacionalidade,
    case when b.econ_activity_category_code in ('64320','68322') or c.zcliente is not null then 'S' else 'N' end as centro_inter_colec_s_person_juridica,
    coalesce(g.CPAIS_P, 'PT') as Sede,
    h.iclipep, h.Tipo_PEP as cargo_pep,
    j.employer_name, cast(coalesce(k.patrimonio, 0) as decimal(16,2)) as valor_patrimonio_liquido,
    case when m.zcliente is not null then 'S' else 'N' end as ARI,
    case when l.party_id is not null then 'S' else 'N' end as org_s_fins_lucrativos,
    case when n.party_id is not null then 'S' else 'N' end as activ_area_risco_elevado,
    case 
        when n.party_id is not null and n.econ_activity_category_code in ('46190','47790', '47910', '82990') then 'Atividade leiloeira ou prestamista' 
        when n.party_id is not null and n.econ_activity_category_code in ('92001','92002') then 'Atividades associadas a jogo'
        when n.party_id is not null and n.econ_activity_category_code in ('93120','93192') then 'Atividades associadas a operações de alienação e aquisição de direitos sobre praticantes de atividades desportivas profissionais'
        when n.party_id is not null and n.econ_activity_category_code in ('24410','24450','32122','32123','46480','46820','49200','49410','50200','50400','51210') then 'Atividades de importação e exportação de diamantes ou pedras preciosas, ou de ouro ou outros metais preciosos'
        when n.party_id is not null and n.econ_activity_category_code in ('64310','64320','66120','66300','80011') then 'Atividades de transporte, tratamento e distribuição de fundo de valores'
        when n.party_id is not null and n.econ_activity_category_code in ('68110','68120','68200','68310','68321','68323','68324') then 'Atividades Imobiliárias exercidas por entidades não financeiras'
        when n.party_id is not null and n.econ_activity_category_code in ('47770','47783','47920') then 'Atividades relacionadas com comercio de arte ou antiguidades'
        when n.party_id is not null and n.econ_activity_category_code in ('84210','94110','94200','94910','94991','94992','94993','94994','94995') then 'Organizações sem fins lucrativos'
    else 'N' 
    end as activ_area_risco_elevado_grupo,
    case when o.sintra is not null then 'S' else 'N' end as estrutura_complexa
from base_cli a
left join
    cae b
on a.party_id = b.party_id
left join
    socied_heranc_massa_insolvencia c
on cast(a.party_id as bigint) = cast(c.zcliente as bigint)
left join
    nac_fisicos d
on a.party_id = d.party_id
left join
    res_fisicos e
on a.party_id = e.party_id
left join
    res_juridicos f
on a.party_id = f.party_id
left join
    origin_juridicos g
on a.party_id = g.party_id
left join
    peps h
on a.party_id = h.zcliente
left join
    entidade_patronal j
on a.party_id = j.party_id
left join
    patrimonio k
on a.party_id = k.zcliente
left join
    organiz_s_fins_lucrativos l
on a.party_id = l.party_id
left join
    aris m
on a.party_id = m.zcliente
left join atividades_risco_elevado n
on a.party_id = n.party_id
left join estruturas_complexas o
on cast(a.party_id as bigint) = o.sintra
left join
(
  select *
  from common_parties_core.party_fusion
  where data_date_part = '2025-12-31'
) c
on a.party_id = c.fusion_party_id
where c.fusion_party_id is null    
""")

tbl_union.createOrReplaceTempView("tbl_union")
tbl_union.display()

# COMMAND ----------

tbl_universo = (tbl_union.distinct())

## Registo de BD
spark.sql("DROP TABLE IF EXISTS workbench_fcc.rpb25_universo_parties_trf_fundos")
tbl_universo.write.format("delta").mode("overwrite").option("mergeSchema", "true").saveAsTable("workbench_fcc.rpb25_universo_parties_trf_fundos")

# COMMAND ----------

# MAGIC %sql
# MAGIC select party_id, count(*) from workbench_fcc.rpb25_universo_parties_trf_fundos
# MAGIC group by party_id
# MAGIC having count(*) > 1

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from workbench_fcc.rpb25_universo_parties_trf_fundos
# MAGIC where party_id = '276454'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from workbench_fcc.rpb25_universo_parties_trf_fundos
# MAGIC where Tipo_Cliente = 'F' and Residencia_Principal is null

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from common_parties_individuals.individual_tax_residence_country
# MAGIC where party_id = '152432'