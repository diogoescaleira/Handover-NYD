# Databricks notebook source
# DBTITLE 1,Variáveis
#importar bibliotecas spark
from pyspark.sql.functions import col,substr,concat,lit,trim

#declaração de variáveis
data_date_part_init = "'2025-01-01'"
data_date_part_fin = "'2025-12-31'"

print(data_date_part_init)
print(data_date_part_fin)

# COMMAND ----------

# DBTITLE 1,Contratos e Relações Elegíveis
## Obtenção de Contratos e Relações Elegíveis
## Exclui-se do âmbito os Produtos de Cartão de Refeição
## Exclui-se do âmbito Factoring e CPP

tbl_conta_cliente = spark.sql(f"""

select distinct c.cconta, a.party_id, partenon_id, concat('TOT', substr(partenon_id,1,1), cast(substr(partenon_id,2,10)as int)) as customer_id_final
from(
    select * from(    
        select contract_id, party_id, row_number() over(partition by contract_id order by max_data_date_part desc) as n
        from(
            select trim(contract_id) as contract_id, party_id, contract_intervention_type_code, contract_intervention_order_num, relationship_start_date, max(data_date_part) as max_data_date_part
            from production.common_contracts_core.contract_party_relationship 
            where data_date_part between '2025-01-01' and '2025-12-31'
            and contract_intervention_type_code = '1' and contract_intervention_order_num = '1'  -- Apenas relação de 1º Titulares
            group by trim(contract_id), party_id, contract_intervention_type_code, contract_intervention_order_num, relationship_start_date
        )
    )
    where n = 1
) a
inner join(
    select * from(
        select *, row_number() over (partition by cconta order by data_max_conta desc) as n
        from(
            select distinct common_table_name, trim(contract_id) as contract_id, concat(cbalcao, cnumecta) as cconta, max(data_date_part) data_max_conta
            from common_contracts_core.contract
            where 1=1
            and data_date_part between '2025-01-01' and '2025-12-31'
            and concat(product_id, subproduct_id) not in ('025001','025002')     -- Exclusão de Produtos de Cartão de Refeição
            and product_family_id <> 'FAC'
            and product_family_id <> 'CPP'
            group by common_table_name, trim(contract_id), concat(cbalcao, cnumecta)
        )
    )
    where n = 1 
    and cconta <> '' and cconta <> ' ' and cconta <> '6416'
)c
on trim(a.contract_id) = c.contract_id --and (a.max_data_date_part = c.data_max_conta or date_add(a.max_data_date_part, -1) = c.data_max_conta)
inner join
(
  select party_id, partenon_id, max(data_date_part) as max_data_date_part
  from common_parties_core.party
  where 1=1 
  and data_date_part between '2025-01-01' and '2025-12-31'
  group by party_id, partenon_id
) d
on a.party_id = d.party_id

""")


# COMMAND ----------

# DBTITLE 1,Registo de BD
## Registo de BD
spark.sql("DROP TABLE IF EXISTS workbench_fcc.rpb25_universo_contratos_transf_fundos_v2")
tbl_conta_cliente.write.format("delta").mode("overwrite").option("mergeSchema", "true").saveAsTable("workbench_fcc.rpb25_universo_contratos_transf_fundos_v2")


# COMMAND ----------

# DBTITLE 1,Validação das contas
# MAGIC %sql
# MAGIC select count(distinct cconta) as contas_distintas, count(cconta) as contas
# MAGIC from workbench_fcc.rpb25_universo_contratos_transf_fundos

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(distinct cconta) as contas_distintas, count(cconta) as contas
# MAGIC from workbench_fcc.rpb25_universo_contratos_transf_fundos_v2

# COMMAND ----------

# DBTITLE 1,Validação Clientes Distintos
# MAGIC %sql
# MAGIC select count(distinct party_id) as titulares
# MAGIC from workbench_fcc.rpb25_universo_contratos_transf_fundos

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(distinct party_id) as titulares
# MAGIC from workbench_fcc.rpb25_universo_contratos_transf_fundos_v2

# COMMAND ----------

# DBTITLE 1,Validação Tabela Final
# MAGIC %sql
# MAGIC select * 
# MAGIC from workbench_fcc.rpb25_universo_contratos_transf_fundos
# MAGIC order by cconta, party_id

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(data_date_part) from common_contracts_core.contract