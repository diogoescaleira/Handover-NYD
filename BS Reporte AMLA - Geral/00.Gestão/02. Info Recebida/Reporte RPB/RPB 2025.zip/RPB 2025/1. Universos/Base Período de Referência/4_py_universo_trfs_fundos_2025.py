# Databricks notebook source
# MAGIC %md
# MAGIC ### Utils

# COMMAND ----------

# DBTITLE 1,Imports
from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import SparkSession


# COMMAND ----------

# DBTITLE 1,Sessão Spark
spark = SparkSession.builder \
    .appName("trf_fundos_rpb25") \
    .getOrCreate()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Base de Contas e Clientes

# COMMAND ----------

# DBTITLE 1,Base
conta_cli = spark.sql(f"""
    select distinct cconta, party_id, partenon_id, customer_id_final
    from production.workbench_fcc.rpb25_universo_contratos_transf_fundos
""")

# display(conta_cli)
conta_cli.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### SWIFTS
# MAGIC

# COMMAND ----------

# DBTITLE 1,Base Enviadas
swifts_env_df = spark.sql(f"""
  select
    *,
    'PT' pais_ord,
    case 
      when 
        regexp_replace(bic_destino,'[^a-zA-Z]','') <> '' 
      then substr(bic_destino,5,2) 
      when 
        regexp_replace(substr(iban_destino,1,2),'[^a-zA-Z]','') <> '' 
      then substr(iban_destino,1,2)
    else 'PT' 
    end as pais_ben,
    iban_ordenante conta
  from(  
    select
      'SWIFT' tipo,	
      trim(Referencia) referencia,
      Montante montante_eur,
      'E' as direcao,
      Data_Valor as data_liq,
      lpad(Conta,15,'0') iban_ordenante,
      'TOTAPTPL' bic_ordenante,
      Cliente_Sintra party_id_ord,
      Cliente_Partenon partenon_id_ord,
      upper(regexp_replace(IBAN_Destino,'[ /.-]','')) as iban_destino,
      upper(regexp_replace(BIC_DESTINO,'[ ]','')) as bic_destino,
      'null' party_id_ben,
      'null' partenon_id_ben
    from workbench_fcc.swift_enviadas_rpb25_v2
  )
""")

swifts_env_df.display()
swifts_env_df.count()

# COMMAND ----------

# DBTITLE 1,Preenchimento Info Enviadas
swifts_env_final = swifts_env_df.join(conta_cli, (F.col('partenon_id_ord') == F.col('partenon_id')) & (F.col('conta') == F.col('cconta')), 'left')

columns_left = swifts_env_df.columns

swifts_env_final = swifts_env_final.select(
    *[F.col(c) for c in columns_left],
    F.col('customer_id_final')
).withColumn(
    'customer_id_final', 
    F.when(
        F.col('customer_id_final').isNull(),
        F.concat(F.lit('TOT'), F.col('partenon_id_ord').substr(1, 1), F.col('partenon_id_ord').substr(2, 100))
    ).otherwise(F.col('customer_id_final'))
)

swifts_env_final.display()
swifts_env_final.count()
# swifts_env_final.filter(F.col('customer_id_final').isNull()).count() #sem customer_id_final nulos

# COMMAND ----------

# DBTITLE 1,Base Recebidas
swifts_rec_df = spark.sql(f"""
    select
        *,
        case 
        when 
            regexp_replace(bic_ordenante,'[^a-zA-Z]','') <> '' 
        then substr(bic_ordenante,5,2) 
        when 
            regexp_replace(substr(iban_ordenante,1,2),'[^a-zA-Z]','') <> '' 
        then substr(iban_ordenante,1,2)
        else 'PT' 
        end as pais_ord,
        'PT' pais_ben,
        case 
            when substr(iban_destino,1,8) = 'PT500018' or substr(iban_destino,1,4) = 'PT87' or substr(iban_destino,1,4) = 'PTS0' or substr(iban_destino,1,4) = 'PY50' or substr(iban_destino,1,4) = 'PY5O' or substr(iban_destino,1,4) = 'PO50' or substr(iban_destino,1,4) = 'PF50' or substr(iban_destino,1,4) = 'PR50' then substr(iban_destino,9,15)
            when substr(iban_destino,3,8) = 'PT500018' then substr(iban_destino,11,15)
            when substr(iban_destino,1,6) = '500018' then substr(iban_destino,7,15)
            when substr(iban_destino,1,4) = '0018' then substr(iban_destino,5,15)
            when substr(iban_destino,1,5) = '00118' then substr(iban_destino,6,15)
            when substr(iban_destino,1,4) = '0003' then substr(iban_destino,1,15)
            when substr(iban_destino,1,4) = 'PT50' then substr(iban_destino,9,15)
            when substr(iban_destino,1,2) = 'PT' or substr(iban_destino,1,2) = '31' then substr(iban_destino,3,15)
            when substr(iban_destino,1,8) = 'TP500018' or substr(iban_destino,1,8) = 'TOTA0018' then substr(iban_destino,9,15)
            when substr(iban_destino,1,16) = 'TOTAPTPLPT500018' then substr(iban_destino,17,15)
            when substr(iban_destino,1,8) = 'TOTAPTPL' then substr(iban_destino,9,15)
            when substr(iban_destino,1,7) = 'T500018' or substr(iban_destino,1,7) = 'P500018' or substr(iban_destino,1,7) = 'NIB0018' then substr(iban_destino,8,15)
            when substr(iban_destino,1,12) = 'IBANPT500018' then substr(iban_destino,13,15)
            when substr(iban_destino,1,13) = 'IBAN:PT500018' then substr(iban_destino,14,15)
            when substr(iban_destino,1,13) = 'PT5000018' then substr(iban_destino,10,15)
            when (substr(iban_destino,1,1) = '3' or substr(iban_destino,1,2) = '03' or substr(iban_destino,1,3) = '003') and len(iban_destino) < 15 then lpad(iban_destino,15,0)
        else iban_destino end as conta
    from(  
        select
        'SWIFT' tipo,	
        referencia,
        montante_eur,
        'R' as direcao,
        Data_Valor as data_liq,
        upper(regexp_replace(iban_ordenante,'[ /.-]','')) as iban_ordenante,
        bic_ordenante,
        'null' party_id_ord,
        'null' partenon_id_ord,
        upper(regexp_replace(iban_destino,'[ /.-]','')) as iban_destino,
        'TOTAPTPL' as bic_destino
        from workbench_fcc.swift_recebidas_rpb25_v3
    )
""")

display(swifts_rec_df)

# COMMAND ----------

# DBTITLE 1,Preenchimento Info Ord e Bef
swifts_rec_final = swifts_rec_df.join(conta_cli, F.col('conta') == F.col('cconta'), 'left')

swifts_rec_final = swifts_rec_final.select(
    F.col('tipo'),
    F.col('referencia'),
    F.col('montante_eur'),
    F.col('direcao'),
    F.col('data_liq'),
    F.col('iban_ordenante'),
    F.col('bic_ordenante'),
    F.col('party_id_ord'),
    F.col('partenon_id_ord'),
    F.col('iban_destino'),
    F.col('bic_destino'),
    F.col('party_id').alias('party_id_ben'),
    F.col('partenon_id').alias('partenon_id_ben'),
    F.col('pais_ord'),
    F.col('pais_ben'),
    F.col('conta'),
    F.col('customer_id_final')
)

swifts_rec_final.display()
swifts_rec_final.count()

# COMMAND ----------

# DBTITLE 1,customer_id a null
# 27 763 nulos --> são algumas contas já canceladas e transações de banca correspondente

swifts_rec_final.unionAll(swifts_env_final).filter(F.col('customer_id_final').isNull()).count()

# COMMAND ----------

# DBTITLE 1,DF Final
#removidas trxs onde não foi possivel identificar o customer_id_final
rpb25_swifts_final = swifts_rec_final.unionAll(swifts_env_final).filter(F.col('customer_id_final').isNotNull())

# rpb25_swifts_final.display()
rpb25_swifts_final.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### SEPA CT

# COMMAND ----------

# DBTITLE 1,Base
sepas_ct = spark.sql(f"""
    select
        *,
        substr(iban_ordenante,1,2) pais_ord,
        substr(iban_destino,1,2) pais_ben,
        case
            when direcao = 'R' then substr(iban_destino,9,15)
            else substr(iban_ordenante,9,15) 
        end as conta
    from(    
        select 
            TIPO_TRF tipo,
            REFERENCIA referencia,
            MONTANTE montante_eur,
            `E/R` as direcao,
            DATA as data_liq,
            IBAN_ORDENANTE as iban_ordenante,
            'null' as bic_ordenante,
            CLIENTE_S party_id_ord,
            CLIENTE_P partenon_id_ord,
            IBAN_DESTINO iban_destino,
            'null' as bic_destino
        from workbench_fcc.sepa_ct_rpb25
    )
""")

display(sepas_ct)   
sepas_ct.count()


# COMMAND ----------

# DBTITLE 1,Preenchimento Info Ord e Bef
sepas_ct_rec = sepas_ct.filter(F.col('direcao') == 'R')
sepas_ct_env = sepas_ct.filter(F.col('direcao') == 'E')

aux_rec = sepas_ct_rec.join(conta_cli, F.col('conta') == F.col('cconta'), 'left')

sepas_ct_rec_inter = aux_rec.select(
    F.col('tipo'),
    F.col('referencia'),
    F.col('montante_eur'),
    F.col('direcao'),
    F.col('data_liq'),
    F.col('iban_ordenante'),
    F.col('bic_ordenante'),
    F.col('party_id_ord'),
    F.col('partenon_id_ord'),
    F.col('iban_destino'),
    F.col('bic_destino'),
    F.col('party_id').alias('party_id_ben'),
    F.col('partenon_id').alias('partenon_id_ben'),
    F.col('pais_ord'),
    F.col('pais_ben'),
    F.col('conta'),
    F.col('customer_id_final')
)

aux_env = sepas_ct_env.join(conta_cli, F.substring(F.col('iban_destino'),9,15) == F.col('cconta'), 'left')

aux_env_2 = aux_env.select(
    F.col('tipo'),
    F.col('referencia'),
    F.col('montante_eur'),
    F.col('direcao'),
    F.col('data_liq'),
    F.col('iban_ordenante'),
    F.col('bic_ordenante'),
    F.col('party_id_ord'),
    F.col('partenon_id_ord'),
    F.col('iban_destino'),
    F.col('bic_destino'),
    F.col('party_id').alias('party_id_ben'),
    F.col('partenon_id').alias('partenon_id_ben'),
    F.col('pais_ord'),
    F.col('pais_ben'),
    F.col('conta')
)

sepas_ct_env_inter = aux_env_2.join(conta_cli, F.col('conta') == F.col('cconta'), 'left')

sepas_ct_env_inter = sepas_ct_env_inter.select(
    F.col('tipo'),
    F.col('referencia'),
    F.col('montante_eur'),
    F.col('direcao'),
    F.col('data_liq'),
    F.col('iban_ordenante'),
    F.col('bic_ordenante'),
    F.col('party_id_ord'),
    F.col('partenon_id_ord'),
    F.col('iban_destino'),
    F.col('bic_destino'),
    F.col('party_id_ben'),
    F.col('partenon_id_ben'),
    F.col('pais_ord'),
    F.col('pais_ben'),
    F.col('conta'),
    F.col('customer_id_final')
)

# display(sepas_ct_rec_inter)
print("Recebidas:",sepas_ct_rec_inter.count(), "Enviadas:",sepas_ct_env_inter.count(), "Total:", sepas_ct_rec_inter.count() + sepas_ct_env_inter.count())


# COMMAND ----------

# DBTITLE 1,customer_id a null
# 2 049 266 de trxs que não apanhamos os titulares porque são IBANs dedicados, cartões refeição (1.9M) ou factoring

sepas_ct_rec_inter.unionAll(sepas_ct_env_inter).filter(F.col('customer_id_final').isNull()).count()
# uniao = sepas_ct_rec_inter.unionAll(sepas_ct_env_inter).filter(F.col('customer_id_final').isNull())

# uniao.createOrReplaceTempView("tst")

# COMMAND ----------

# DBTITLE 1,Base de duplicação TRX sem espelho
base_sepas = sepas_ct_rec_inter.unionAll(sepas_ct_env_inter).filter(F.col('customer_id_final').isNotNull())

# Chave como na query (concat de montante_eur, iban_ordenante, iban_destino, data_liq)
chave = F.concat(
    F.col("montante_eur").cast("string"),
    F.trim(F.col("iban_ordenante")),
    F.trim(F.col("iban_destino")),
    F.col("data_liq").cast("string"),
)

# subquery: chaves que cumprem filtros e aparecem exatamente 1 vez
chaves_unicas = (
    base_sepas
    .where(
        (F.substring(F.col("iban_ordenante"), 1, 8) == "PT500018")
        & (F.substring(F.col("iban_destino"),   1, 8) == "PT500018")
        & (F.col("party_id_ord") != F.col("party_id_ben"))
    )
    .groupBy(chave.alias("chave"))
    .agg(F.count(F.lit(1)).alias("cnt"))
    .where(F.col("cnt") == 1)
    .select("chave")
)

# SELECT * FROM base_dups WHERE chave IN (subquery)
base_dups = (
    base_sepas
    .withColumn("chave", chave)
    .join(F.broadcast(chaves_unicas), on="chave", how="inner")  # broadcast opcional
    .drop("chave")
)


base_dups.count()

# COMMAND ----------

# DBTITLE 1,Preparação da base de dups
# Helpers para calcular o customer_id_final a partir de um partenon_id
def customer_from_partenon(colname: str):
    c = F.col(colname)
    return F.concat(
        F.lit("TOT"),
        F.substring(c, 1, 1),
        F.substring(c, 2, 9).cast("int").cast("string"),
    )

cust_ord = customer_from_partenon("partenon_id_ord")
cust_ben = customer_from_partenon("partenon_id_ben")

base_dups_final = (
    base_dups
    .withColumn("direcao_orig", F.col("direcao"))
    .withColumn(
        "direcao",
        F.when(F.col("direcao_orig") == "E", "R")
         .when(F.col("direcao_orig") == "R", "E")
         .otherwise(F.col("direcao_orig"))
    )
    .withColumn(
        "customer_id_final",
        F.when(F.col("direcao_orig") == "E", cust_ben)   # direção original = E -> usa BEN
         .when(F.col("direcao_orig") == "R", cust_ord)   # direção original = R -> usa ORD
         .otherwise(F.col("customer_id_final"))
    )
    .drop("direcao_orig")
)

base_dups_final.count()

# COMMAND ----------

# DBTITLE 1,DF Final
rpb25_sepas_ct_final = base_sepas.unionAll(base_dups_final)

rpb25_sepas_ct_final.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### TARGET

# COMMAND ----------

# DBTITLE 1,Base Enviadas
target_env = spark.sql(f"""
    select 
        *,
        'PT' pais_ord,
        case 
            when 
                regexp_replace(bic_destino,'[^a-zA-Z]','') <> '' 
            then substr(bic_destino,5,2) 
            when 
                regexp_replace(substr(iban_destino,1,2),'[^a-zA-Z]','') <> '' 
            then substr(iban_destino,1,2)
            else 'PT' 
        end as pais_ben,
        iban_ordenante conta
    from(
        select
            TIPO_TRF as tipo,
            REFERENCIA as referencia,
            CONTRAVALOR as montante_eur,
            `E/R` as direcao,
            `DATA` as data_liq,
            lpad(IBAN_ORDENANTE,15,'0') iban_ordenante,
            'TOTAPTPL' bic_ordenante,
            CLIENTE_S as party_id_ord,
            CLIENTE_P as partenon_id_ord,
            upper(regexp_replace(IBAN_DESTINO,'[ /.-]','')) as iban_destino,
            upper(regexp_replace(BIC_DESTINO,'[ ]','')) as bic_destino,
            'null' party_id_ben,
            'null' partenon_id_ben
        from workbench_fcc.target_env_rpb25
    )
""")

target_env.display()
target_env.count()

# COMMAND ----------

# DBTITLE 1,Preenchimento Inf Enviadas
target_env_final = target_env.join(conta_cli, (F.col('partenon_id_ord') == F.col('partenon_id')) & (F.col('conta') == F.col('cconta')), 'left')

columns_left = target_env.columns

target_env_final = target_env_final.select(
    *[F.col(c) for c in columns_left],
    F.col('customer_id_final')
).withColumn(
    'customer_id_final', 
    F.when(
        F.col('customer_id_final').isNull(),
        F.concat(F.lit('TOT'), F.col('partenon_id_ord').substr(1, 1),F.col('partenon_id_ord').substr(2, 100))
    ).otherwise(F.col('customer_id_final'))
)

target_env_final.display()
target_env_final.count()
# target_env_final.filter(F.col('customer_id_final').isNull()).count() #sem customer_id_final nulos

# COMMAND ----------

# DBTITLE 1,Base Recebidas
target_rec = spark.sql(f"""
    select
        *,
        case 
        when 
            regexp_replace(bic_ordenante,'[^a-zA-Z]','') <> '' 
        then substr(bic_ordenante,5,2) 
        when 
            regexp_replace(substr(iban_ordenante,1,2),'[^a-zA-Z]','') <> '' 
        then substr(iban_ordenante,1,2)
        else 'PT' 
        end as pais_ord,
        'PT' pais_ben,
        case 
            when substr(iban_destino,1,8) = 'PT500018' or substr(iban_destino,1,4) = 'PT87' or substr(iban_destino,1,4) = 'PTS0' or substr(iban_destino,1,4) = 'PY50' or substr(iban_destino,1,4) = 'PY5O' or substr(iban_destino,1,4) = 'PO50' or substr(iban_destino,1,4) = 'PF50' or substr(iban_destino,1,4) = 'PR50' then substr(iban_destino,9,15)
            when substr(iban_destino,3,8) = 'PT500018' then substr(iban_destino,11,15)
            when substr(iban_destino,1,6) = '500018' then substr(iban_destino,7,15)
            when substr(iban_destino,1,4) = '0018' then substr(iban_destino,5,15)
            when substr(iban_destino,1,5) = '00118' then substr(iban_destino,6,15)
            when substr(iban_destino,1,4) = '0003' then substr(iban_destino,1,15)
            when substr(iban_destino,1,4) = 'PT50' then substr(iban_destino,9,15)
            when substr(iban_destino,1,2) = 'PT' or substr(iban_destino,1,2) = '31' then substr(iban_destino,3,15)
            when substr(iban_destino,1,8) = 'TP500018' or substr(iban_destino,1,8) = 'TOTA0018' then substr(iban_destino,9,15)
            when substr(iban_destino,1,16) = 'TOTAPTPLPT500018' then substr(iban_destino,17,15)
            when substr(iban_destino,1,8) = 'TOTAPTPL' then substr(iban_destino,9,15)
            when substr(iban_destino,1,7) = 'T500018' or substr(iban_destino,1,7) = 'P500018' or substr(iban_destino,1,7) = 'NIB0018' then substr(iban_destino,8,15)
            when substr(iban_destino,1,12) = 'IBANPT500018' then substr(iban_destino,13,15)
            when substr(iban_destino,1,13) = 'IBAN:PT500018' then substr(iban_destino,14,15)
            when substr(iban_destino,1,13) = 'PT5000018' then substr(iban_destino,10,15)
            when (substr(iban_destino,1,1) = '3' or substr(iban_destino,1,2) = '03' or substr(iban_destino,1,3) = '003') and len(iban_destino) < 15 then lpad(iban_destino,15,0)
        else iban_destino end as conta
    from(  
        select
            TIPO_TRF as tipo,
            REFERENCIA as referencia,
            CONTRAVALOR as montante_eur,
            `E/R` as direcao,
            `DATA` as data_liq,
            upper(regexp_replace(IBAN_ORDENANTE,'[ /.-]','')) as iban_ordenante,
            upper(regexp_replace(BIC_ORDENANTE,'[ ]','')) as bic_ordenante,
            'null' party_id_ord,
            'null' partenon_id_ord,
            upper(regexp_replace(IBAN_DESTINO,'[ /.-]','')) as iban_destino,
            'TOTAPTPL' bic_destino
        from workbench_fcc.target_rec_rpb25
        where SITUACAO <> 'DV'              --exclusão de devolvidas
    )
""")

target_rec.display()
target_rec.count()

# COMMAND ----------

# DBTITLE 1,Preenchimento Info Ord e Bef
target_rec_final = target_rec.join(conta_cli, F.col('conta') == F.col('cconta'), 'left')

target_rec_final = target_rec_final.select(
    F.col('tipo'),
    F.col('referencia'),
    F.col('montante_eur'),
    F.col('direcao'),
    F.col('data_liq'),
    F.col('iban_ordenante'),
    F.col('bic_ordenante'),
    F.col('party_id_ord'),
    F.col('partenon_id_ord'),
    F.col('iban_destino'),
    F.col('bic_destino'),
    F.col('party_id').alias('party_id_ben'),
    F.col('partenon_id').alias('partenon_id_ben'),
    F.col('pais_ord'),
    F.col('pais_ben'),
    F.col('conta'),
    F.col('customer_id_final')
)

target_rec_final.display()
target_rec_final.count()


# COMMAND ----------

# DBTITLE 1,customer_id a null
 # 13 481 nulos --> são algumas contas já canceladas e transações de banca correspondente

target_rec_final.unionAll(target_env_final).filter(F.col('customer_id_final').isNull()).count()

# COMMAND ----------

# DBTITLE 1,DF Final
#removidas trxs onde não foi possivel identificar o customer_id_final
rpb25_target_final = target_rec_final.unionAll(target_env_final).filter(F.col('customer_id_final').isNotNull())

# rpb25_target_final.display()
rpb25_target_final.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### SEPAS DD

# COMMAND ----------

# DBTITLE 1,Base
sepas_dd_base = spark.sql(f"""
    select *,
        substr(iban_ordenante,1,2) pais_ord,
        substr(iban_destino,1,2) pais_ben,
        case
            when direcao = 'R' then substr(iban_destino,9,15)
            else substr(iban_ordenante,9,15) 
        end as conta
    from(
        select 'DD' tipo, DDYD03A4_CREFOPR referencia, 'E' direcao, DDYD03A4_MMOVIM montante_eur, DDYD03A4_DTLIQUID data_liq,
            DDYD03A4_CIBANDEV iban_ordenante, DDYD03A4_CBICDEV bic_ordenante, DDYD03A4_CIBANCRE iban_destino,
            DDYD03A4_CBICCRE bic_destino
        from production.curated_internal_mainframe_debitosdirectos.ddt03_iddrec
        where DDYD03A4_DTLIQUID between '2025-01-01' and '2025-12-31'
        AND DDYD03A4_CIBANDEV LIKE 'PT500018%'
        and DDYD03A4_CESTADO = 'COB'
        union all
        select 'DD' tipo, DDYD03A4_CREFOPR referencia, 'R' direcao, DDYD03A4_MMOVIM montante_eur, DDYD03A4_DTLIQUID data_liq,
            DDYD03A4_CIBANDEV iban_ordenante, DDYD03A4_CBICDEV bic_ordenante, DDYD03A4_CIBANCRE iban_destino,
            DDYD03A4_CBICCRE bic_destino
        from production.curated_internal_mainframe_debitosdirectos.ddt03_iddrec
        where DDYD03A4_DTLIQUID between '2025-01-01' and '2025-12-31'
        AND DDYD03A4_CIBANCRE LIKE 'PT500018%'
        and DDYD03A4_CESTADO = 'COB'
    )
""")

sepas_dd_base.display()
sepas_dd_base.count()

# COMMAND ----------

# DBTITLE 1,Preenchimento Info Ord
sepas_dd_rec = sepas_dd_base.filter(F.col('direcao') == 'R')
sepas_dd_env = sepas_dd_base.filter(F.col('direcao') == 'E')

aux_ddrec = sepas_dd_rec.join(conta_cli, F.col('conta') == F.col('cconta'), 'left')

aux_ddrec = aux_ddrec.select(
    F.col('tipo'),
    F.col('referencia'),
    F.col('montante_eur'),
    F.col('direcao'),
    F.col('data_liq'),
    F.col('iban_ordenante'),
    F.col('bic_ordenante'),
    F.col('iban_destino'),
    F.col('bic_destino'),
    F.col('party_id').alias('party_id_ben'),
    F.col('partenon_id').alias('partenon_id_ben'),
    F.col('pais_ord'),
    F.col('pais_ben'),
    F.col('conta'),
    F.col('customer_id_final')
)

aux_ddrec = aux_ddrec.alias('aux')
conta_cli = conta_cli.alias('cli')

aux_ddrec_2 = aux_ddrec.join(conta_cli, F.substring(F.col('iban_ordenante'),9,15) == F.col('cconta'), 'left')

sepa_dd_rec_inter = aux_ddrec_2.select(
    F.col('aux.tipo'),
    F.col('aux.referencia'),
    F.col('aux.montante_eur'),
    F.col('aux.direcao'),
    F.col('aux.data_liq'),
    F.col('aux.iban_ordenante'),
    F.col('aux.bic_ordenante'),
    F.col('cli.party_id').alias('party_id_ord'),
    F.col('cli.partenon_id').alias('partenon_id_ord'),
    F.col('aux.iban_destino'),
    F.col('aux.bic_destino'),
    F.col('aux.party_id_ben'),
    F.col('aux.partenon_id_ben'),
    F.col('aux.pais_ord'),
    F.col('aux.pais_ben'),
    F.col('aux.conta'),
    F.col('aux.customer_id_final')
)

sepa_dd_rec_inter.display()
sepa_dd_rec_inter.count()


# COMMAND ----------

# DBTITLE 1,Preenchimento Info Bef
aux_ddenv = sepas_dd_env.join(conta_cli, F.col('conta') == F.col('cconta'), 'left')

aux_ddenv = aux_ddenv.select(
    F.col('tipo'),
    F.col('referencia'),
    F.col('montante_eur'),
    F.col('direcao'),
    F.col('data_liq'),
    F.col('iban_ordenante'),
    F.col('bic_ordenante'),
    F.col('party_id').alias('party_id_ord'),
    F.col('partenon_id').alias('partenon_id_ord'),
    F.col('iban_destino'),
    F.col('bic_destino'),
    F.col('pais_ord'),
    F.col('pais_ben'),
    F.col('conta'),
    F.col('customer_id_final')
)

aux_ddenv = aux_ddenv.alias('aux')
conta_cli = conta_cli.alias('cli')

aux_ddenv_2 = aux_ddenv.join(conta_cli, F.substring(F.col('iban_destino'),9,15) == F.col('cconta'), 'left')

sepa_dd_env_inter = aux_ddenv_2.select(
    F.col('aux.tipo'),
    F.col('aux.referencia'),
    F.col('aux.montante_eur'),
    F.col('aux.direcao'),
    F.col('aux.data_liq'),
    F.col('aux.iban_ordenante'),
    F.col('aux.bic_ordenante'),
    F.col('aux.party_id_ord'),
    F.col('aux.partenon_id_ord'),
    F.col('aux.iban_destino'),
    F.col('aux.bic_destino'),
    F.col('cli.party_id').alias('party_id_ben'),
    F.col('cli.partenon_id').alias('partenon_id_ben'),
    F.col('aux.pais_ord'),
    F.col('aux.pais_ben'),
    F.col('aux.conta'),
    F.col('aux.customer_id_final')
)

sepa_dd_env_inter.display()

print("Recebidas:",sepa_dd_rec_inter.count(), "Enviadas:",sepa_dd_env_inter.count(), "Total:", sepa_dd_rec_inter.count() + sepa_dd_env_inter.count())

# COMMAND ----------

# DBTITLE 1,customer_id a null
# 3 501 de trxs que não apanhamos os titulares porque as contas encerraram durante 2025

sepa_dd_rec_inter.unionAll(sepa_dd_env_inter).filter(F.col('customer_id_final').isNull()).count()

# COMMAND ----------

# DBTITLE 1,DF Final
rpb25_sepas_dd_final = sepa_dd_rec_inter.unionAll(sepa_dd_env_inter).filter(F.col('customer_id_final').isNotNull())

rpb25_sepas_dd_final.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### MBWAYs

# COMMAND ----------

# DBTITLE 1,Base
mbways = spark.sql(f"""
    select a.*, 
        c.direcao,
        substr(iban_ordenante,1,2) pais_ord,
        substr(iban_destino,1,2) pais_ben,
        case
            when c.direcao = 'R' then substr(iban_destino,9,15)
            else substr(iban_ordenante,9,15) 
        end as conta
    from(
        select 
            TIPO_TRF tipo,
            REFERENCIA referencia,
            MONTANTE montante_eur,
            `DATA` data_liq,
            IBAN_ORDENANTE iban_ordenante,
            'null' bic_ordenante,
            CLIENTE_S party_id_ord,
            CLIENTE_P partenon_id_ord,
            IBAN_DESTINO iban_destino,
            'null' bic_destino
        from production.workbench_fcc.mbway2025  
    ) a
    left join(
        select *,
        case 
            when ctranscr = '179' then 'E' 
            when ctranscr = '199' then 'R'
        else 'outro' end as direcao
        from curated_internal_mainframe_cartoes.crt67
        where ddatacr between '2025-01-01' and '2025-12-31'
    ) c
    on lpad(a.referencia,14,'0') = c.crefercr and cast(a.data_liq as string) = c.ddatacr and a.montante_eur = cast(c.mmovim as double)

""")

mbways.display()
mbways.count()

# COMMAND ----------

# DBTITLE 1,Preenchimento Info Ord e Bef
mbways_rec = mbways.filter(F.col('direcao') == 'R')
mbways_env = mbways.filter(F.col('direcao') == 'E')

aux_mbway_rec = mbways_rec.join(conta_cli, F.col('conta') == F.col('cconta'), 'left')

mbways_rec_inter = aux_mbway_rec.select(
    F.col('tipo'),
    F.col('referencia'),
    F.col('montante_eur'),
    F.col('direcao'),
    F.col('data_liq'),
    F.col('iban_ordenante'),
    F.col('bic_ordenante'),
    F.col('party_id_ord'),
    F.col('partenon_id_ord'),
    F.col('iban_destino'),
    F.col('bic_destino'),
    F.col('party_id').alias('party_id_ben'),
    F.col('partenon_id').alias('partenon_id_ben'),
    F.col('pais_ord'),
    F.col('pais_ben'),
    F.col('conta'),
    F.col('customer_id_final')
)

aux_mbway_env = mbways_env.join(conta_cli, F.substring(F.col('iban_destino'),9,15) == F.col('cconta'), 'left')

aux_mbway_env_2 = aux_mbway_env.select(
    F.col('tipo'),
    F.col('referencia'),
    F.col('montante_eur'),
    F.col('direcao'),
    F.col('data_liq'),
    F.col('iban_ordenante'),
    F.col('bic_ordenante'),
    F.col('party_id_ord'),
    F.col('partenon_id_ord'),
    F.col('iban_destino'),
    F.col('bic_destino'),
    F.col('party_id').alias('party_id_ben'),
    F.col('partenon_id').alias('partenon_id_ben'),
    F.col('pais_ord'),
    F.col('pais_ben'),
    F.col('conta')
)

mbways_env_inter = aux_mbway_env_2.join(conta_cli, F.col('conta') == F.col('cconta'), 'left')

mbways_env_inter = mbways_env_inter.select(
    F.col('tipo'),
    F.col('referencia'),
    F.col('montante_eur'),
    F.col('direcao'),
    F.col('data_liq'),
    F.col('iban_ordenante'),
    F.col('bic_ordenante'),
    F.col('party_id_ord'),
    F.col('partenon_id_ord'),
    F.col('iban_destino'),
    F.col('bic_destino'),
    F.col('party_id_ben'),
    F.col('partenon_id_ben'),
    F.col('pais_ord'),
    F.col('pais_ben'),
    F.col('conta'),
    F.col('customer_id_final')
)

# display(sepas_ct_rec_inter)
print("Recebidas:",mbways_rec_inter.count(), "Enviadas:",mbways_env_inter.count(), "Total:", mbways_rec_inter.count() + mbways_env_inter.count())


# COMMAND ----------

# DBTITLE 1,customer_id a null
# 10 756 de trxs que não apanhamos os titulares porque as contas encerraram durante 2025

mbways_rec_inter.unionAll(mbways_env_inter).filter(F.col('customer_id_final').isNull()).count()

# COMMAND ----------

# DBTITLE 1,DF Final
rpb25_mbway_final = mbways_rec_inter.unionAll(mbways_env_inter).filter(F.col('customer_id_final').isNotNull())

rpb25_mbway_final.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tabelas Finais

# COMMAND ----------

# DBTITLE 1,Criação das Tabelas Finais
rpb25_swifts_final.write.mode('overwrite').saveAsTable('workbench_fcc.rpb25_swifts_final')
rpb25_sepas_ct_final.write.mode('overwrite').saveAsTable('workbench_fcc.rpb25_sepas_ct_final')
rpb25_target_final.write.mode('overwrite').saveAsTable('workbench_fcc.rpb25_target_final')
rpb25_sepas_dd_final.write.mode('overwrite').saveAsTable('workbench_fcc.rpb25_sepas_dd_final')
rpb25_mbway_final.write.mode('overwrite').saveAsTable('workbench_fcc.rpb25_mbway_final')

# COMMAND ----------

# DBTITLE 1,Tabela Final
uniao_tabelas = spark.sql(f"""
    select * from workbench_fcc.rpb25_swifts_final
    union all
    select * from workbench_fcc.rpb25_sepas_ct_final
    union all 
    select * from workbench_fcc.rpb25_target_final
    union all 
    select * from workbench_fcc.rpb25_sepas_dd_final
    union all 
    select * from workbench_fcc.rpb25_mbway_final
""")

uniao_tabelas.write.mode('overwrite').saveAsTable('workbench_fcc.rpb25_transf_fundos')

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*), 'rpb25_swifts_final' from workbench_fcc.rpb25_swifts_final
# MAGIC union all
# MAGIC select count(*), 'rpb25_sepas_ct_final' from workbench_fcc.rpb25_sepas_ct_final
# MAGIC union all 
# MAGIC select count(*), 'rpb25_target_final' from workbench_fcc.rpb25_target_final
# MAGIC union all 
# MAGIC select count(*), 'rpb25_sepas_dd_final' from workbench_fcc.rpb25_sepas_dd_final
# MAGIC union all 
# MAGIC select count(*), 'rpb25_mbway_final' from workbench_fcc.rpb25_mbway_final

# COMMAND ----------

# MAGIC %sql
# MAGIC select tipo, count(*) from workbench_fcc.rpb25_transf_fundos
# MAGIC group by tipo

# COMMAND ----------

dfs = [
    ("rpb25_swifts_final", rpb25_swifts_final),
    ("rpb25_sepas_ct_final", rpb25_sepas_ct_final),
    ("rpb25_sepas_dd_final", rpb25_sepas_dd_final),
    ("rpb25_mbway_final", rpb25_mbway_final),
    ("rpb25_target_final", rpb25_target_final),
]

# Construir uma lista de tuplas com os resultados
result = [(df_name, df.count()) for df_name, df in dfs]

result_df = spark.createDataFrame(result, ["df_name", "count"])

result_df.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select '2025' ano, tipo, direcao , count(*) n_trx, sum(montante_eur) montante_total from workbench_fcc.rpb25_transf_fundos
# MAGIC group by tipo, direcao
# MAGIC union all
# MAGIC select '2024' ano, TIPO_TRF tipo, DIRECAO direcao , count(*) n_trx, sum(MONTANTE) montante_total from workbench_fcc.transf_fundos_rpb2024
# MAGIC group by TIPO_TRF, DIRECAO